// MULTITOOL ARACI - IceGlass Edition
// Sunucu kurma (SCPI / TCP soket)  •  Ethernet ayarı  •  USB panel kontrolü
// Sadece Windows. Sunucular, menü exe'sinden bağımsız arka plan süreci olarak çalışır.
// Konumdan bağımsız: Exe'yi nereye taşırsanız taşıyın, arka plan servisi C:\ProgramData\KeysightSim
// altındaki kopyası üzerinden kesintisiz çalışır ve her menüden durdurulabilir.
//
// Tuşlar (her menüde):
//   Tab        → Ana menüye dön
//   Backspace  → Bir geri git (yazı girişinde: boş satırda Backspace = iptal / geri)
//   n / s / g  → Network / Spectrum / Jeneratör sunucusunu aç-kapat
//   a / k      → Tüm sunucuları başlat / durdur

use std::collections::HashSet;
use std::fs::{self, OpenOptions};
use std::io::{self, BufRead, BufReader, Read, Seek, SeekFrom, Write};
use std::net::{Ipv4Addr, SocketAddr, TcpListener, TcpStream};
use std::os::windows::process::CommandExt;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

const SCPI_PORT: u16 = 5025; // Varsayılan SCPI portu (cihaz başına değiştirilebilir)

// ───────────────────────── Görünüm sabitleri ─────────────────────────
// Not: Konsol yazı tipi (Consolas) yalnızca WGL4 karakter kümesini garanti eder.
// Bu yüzden yuvarlak köşeli kutu karakterleri, emoji ve ✔ ✖ gibi simgeler kullanılmaz;
// aksi halde kare / soru işareti olarak görünüp okunmaz hale gelirler.

const FONT_SIZE: i16 = 18; // Konsol yazı boyutu (piksel yüksekliği)
const CONSOLE_COLS: u32 = 100;
const CONSOLE_LINES: u32 = 46;
const INNER: usize = 92; // Başlık kutusunun iç genişliği

const S_OK: &str = "√";
const S_ERR: &str = "×";
const S_WARN: &str = "!";
const S_ARROW: &str = "►";

const C_RESET: &str = "\x1b[0m";
const C_BOLD: &str = "\x1b[1m";
const C_ICE: &str = "\x1b[38;2;0;229;255m"; // Parlak Buz Mavisi
const C_FROST: &str = "\x1b[38;2;140;200;235m"; // Buğulu Cam Mavisi
const C_WHITE: &str = "\x1b[38;2;240;248;255m"; // Alice White
const C_DIM: &str = "\x1b[38;2;110;135;160m"; // Koyu Buz Gri
const C_NUM: &str = "\x1b[1;38;2;255;215;64m"; // Canlı Altın Sarısı
const C_OK: &str = "\x1b[1;38;2;0;230;118m"; // Neon Yeşil
const C_WARN: &str = "\x1b[1;38;2;255;171;0m"; // Kehribar
const C_ERR: &str = "\x1b[1;38;2;255;82;82m"; // Mercan Kırmızı
const BG_GLASS: &str = "\x1b[48;2;14;28;46m"; // Koyu Buzul Cam Arka Planı

// ───────────────────────── Win32 yerel çağrılar (PowerShell gerektirmez) ─────────────────────────

type Handle = isize;

#[repr(C)]
struct ConsoleFontInfoEx {
    cb_size: u32,
    n_font: u32,
    size_x: i16,
    size_y: i16,
    family: u32,
    weight: u32,
    face: [u16; 32],
}

#[repr(C)]
struct WinTime {
    year: u16,
    month: u16,
    dow: u16,
    day: u16,
    hour: u16,
    minute: u16,
    second: u16,
    ms: u16,
}

extern "system" {
    fn GetStdHandle(n_std_handle: i32) -> Handle;
    fn GetConsoleMode(h: Handle, mode: *mut u32) -> i32;
    fn SetConsoleMode(h: Handle, mode: u32) -> i32;
    fn SetCurrentConsoleFontEx(h: Handle, max_window: i32, info: *const ConsoleFontInfoEx) -> i32;
    fn GetConsoleWindow() -> Handle;
    fn SetConsoleOutputCP(cp: u32) -> i32;
    fn SetConsoleCP(cp: u32) -> i32;
    fn SetConsoleTitleW(title: *const u16) -> i32;
    fn GetLocalTime(st: *mut WinTime);
}

#[link(name = "user32")]
extern "system" {
    fn GetWindowLongW(hwnd: Handle, index: i32) -> i32;
    fn SetWindowLongW(hwnd: Handle, index: i32, value: i32) -> i32;
    fn SetLayeredWindowAttributes(hwnd: Handle, key: u32, alpha: u8, flags: u32) -> i32;
}

extern "C" {
    fn _getwch() -> u16; // Enter gerektirmeden tek tuş okur (Türkçe karakter uyumlu)
}

fn setup_iceglass_console() {
    unsafe {
        SetConsoleOutputCP(65001);
        SetConsoleCP(65001);
        let hout = GetStdHandle(-11);
        let mut mode: u32 = 0;
        if GetConsoleMode(hout, &mut mode) != 0 {
            SetConsoleMode(hout, mode | 0x0004); // ANSI renkleri aç
        }
        let title: Vec<u16> = "MULTITOOL ARACI - IceGlass Edition\0".encode_utf16().collect();
        SetConsoleTitleW(title.as_ptr());

        let mut face = [0u16; 32];
        for (i, c) in "Consolas".encode_utf16().enumerate() {
            face[i] = c;
        }
        let info = ConsoleFontInfoEx {
            cb_size: std::mem::size_of::<ConsoleFontInfoEx>() as u32,
            n_font: 0,
            size_x: 0,
            size_y: FONT_SIZE,
            family: 54,
            weight: 400,
            face,
        };
        SetCurrentConsoleFontEx(hout, 0, &info);

        let hwnd = GetConsoleWindow();
        if hwnd != 0 {
            let ex = GetWindowLongW(hwnd, -20);
            SetWindowLongW(hwnd, -20, ex | 0x80000);
            SetLayeredWindowAttributes(hwnd, 0, 242, 0x2); // hafif yarı saydam cam
        }
    }
    // Pencereyi satır kaymayacak şekilde yeterince geniş yap
    let _ = Command::new("cmd")
        .raw_arg(format!("/C mode con: cols={} lines={}", CONSOLE_COLS, CONSOLE_LINES))
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status();
}

fn ts() -> String {
    let mut t = WinTime { year: 0, month: 0, dow: 0, day: 0, hour: 0, minute: 0, second: 0, ms: 0 };
    unsafe { GetLocalTime(&mut t) };
    format!(
        "{:04}-{:02}-{:02} {:02}:{:02}:{:02}",
        t.year, t.month, t.day, t.hour, t.minute, t.second
    )
}

fn clock() -> String {
    ts().split(' ').nth(1).unwrap_or("").to_string()
}

// ───────────────────────── Tuş & giriş sistemi ─────────────────────────

#[derive(Clone, Copy, PartialEq)]
enum Key {
    Char(char),
    Tab,
    Back,
    Enter,
    Esc,
    Other,
}

#[derive(Clone, Copy, PartialEq)]
enum Nav {
    Back, // bir geri
    Home, // ana menü
}

enum Pick<T> {
    Got(T),
    Back,
    Home,
}

enum Input {
    Text(String),
    Hot(char),
    Back,
    Home,
}

enum Mk {
    Ch(char),
    Back,
    Home,
    None,
}

fn raw_key() -> Key {
    let c = unsafe { _getwch() };
    if c == 0 || c == 0xE0 {
        let _ = unsafe { _getwch() }; // ok tuşları vb. (ikinci kod)
        return Key::Other;
    }
    match c {
        9 => Key::Tab,
        8 => Key::Back,
        13 => Key::Enter,
        27 | 3 => Key::Esc,
        _ => match char::from_u32(c as u32) {
            Some(ch) if !ch.is_control() => Key::Char(ch),
            _ => Key::Other,
        },
    }
}

// Kısayol harflerini küçültür ve Türkçe I/İ/ı farkını ortadan kaldırır
fn hot(c: char) -> char {
    match c {
        'İ' | 'I' | 'ı' => 'i',
        _ => c.to_lowercase().next().unwrap_or(c),
    }
}

fn is_global(c: char) -> bool {
    matches!(c, 'n' | 's' | 'g' | 'a' | 'k')
}

fn read_key(prompt: &str) -> Key {
    print!("  {}{}{} ", C_ICE, prompt, C_WHITE);
    let _ = io::stdout().flush();
    let k = raw_key();
    match k {
        Key::Char(c) => println!("{}{}", c, C_RESET),
        _ => println!("{}", C_RESET),
    }
    k
}

// Satır girişi. Boş satırda Backspace/Esc = Back, Tab = Home.
// hot_extra = Some(..) ise satır başındaki global kısayollar + ekstra harfler Hot olarak döner.
fn read_input(prompt: &str, hot_extra: Option<&[char]>) -> Input {
    print!("  {}{}{} ", C_ICE, prompt, C_WHITE);
    let _ = io::stdout().flush();
    let mut buf = String::new();
    loop {
        match raw_key() {
            Key::Enter => {
                println!("{}", C_RESET);
                return Input::Text(buf.trim().to_string());
            }
            Key::Tab => {
                println!("{}", C_RESET);
                return Input::Home;
            }
            Key::Esc => {
                println!("{}", C_RESET);
                return Input::Back;
            }
            Key::Back => {
                if buf.is_empty() {
                    println!("{}", C_RESET);
                    return Input::Back;
                }
                buf.pop();
                print!("\x08 \x08");
                let _ = io::stdout().flush();
            }
            Key::Char(c) => {
                if buf.is_empty() {
                    if let Some(extra) = hot_extra {
                        let h = hot(c);
                        if is_global(h) || extra.contains(&h) {
                            println!("{}{}", h, C_RESET);
                            return Input::Hot(h);
                        }
                    }
                }
                buf.push(c);
                print!("{}", c);
                let _ = io::stdout().flush();
            }
            Key::Other => {}
        }
    }
}

fn ask_text(prompt: &str) -> Result<String, Nav> {
    match read_input(prompt, None) {
        Input::Text(t) => Ok(t),
        Input::Home => Err(Nav::Home),
        _ => Err(Nav::Back),
    }
}

// Döngü içinde kullanılır: Home → ana menüye; Back → işlemi iptal edip döngüye devam
macro_rules! ask {
    ($prompt:expr) => {
        match ask_text($prompt) {
            Ok(v) => v,
            Err(Nav::Home) => return Nav::Home,
            Err(Nav::Back) => continue,
        }
    };
}

fn confirm(prompt: &str) -> bool {
    match read_key(prompt) {
        Key::Char(c) => matches!(hot(c), 'e' | 'y'),
        _ => false,
    }
}

fn pause() {
    let _ = read_key("Devam etmek için herhangi bir tuşa basın ...");
}

// Menü tuşu: Tab=Ana menü, Backspace/Esc=Geri, n/s/g/a/k=sunucu kontrolü (otomatik işlenir)
fn menu_key(prompt: &str) -> Mk {
    match read_key(prompt) {
        Key::Tab => Mk::Home,
        Key::Back | Key::Esc => Mk::Back,
        Key::Char(c) => {
            let c = hot(c);
            if global_key(c) {
                Mk::None
            } else {
                Mk::Ch(c)
            }
        }
        _ => Mk::None,
    }
}

// ───────────────────────── Bilgi mesajları (menü yeniden çizilince gösterilir) ─────────────────────────

static FLASH: Mutex<Vec<(u8, String)>> = Mutex::new(Vec::new());

fn flash(level: u8, msg: String) {
    FLASH.lock().unwrap_or_else(|e| e.into_inner()).push((level, msg));
}
fn flash_ok(msg: String) {
    flash(0, msg)
}
fn flash_warn(msg: String) {
    flash(1, msg)
}
fn flash_err(msg: String) {
    flash(2, msg)
}

fn cls() {
    print!("\x1b[2J\x1b[3J\x1b[H");
    let _ = io::stdout().flush();
}

// ───────────────────────── Çizim yardımcıları ─────────────────────────

fn hline(n: usize) -> String {
    "─".repeat(n)
}

fn draw_header(subtitle: &str) {
    cls();
    println!("  {}┌{}┐{}", C_ICE, hline(INNER), C_RESET);
    println!(
        "  {}│{}{}{:<w$}{}{}│{}",
        C_ICE,
        BG_GLASS,
        C_BOLD,
        "   MULTITOOL ARACI  │  ICEGLASS EDITION",
        C_RESET,
        C_ICE,
        C_RESET,
        w = INNER
    );
    println!(
        "  {}│{}{}{:<w$}{}{}│{}",
        C_ICE,
        BG_GLASS,
        C_FROST,
        format!("   {}", subtitle),
        C_RESET,
        C_ICE,
        C_RESET,
        w = INNER
    );
    println!("  {}└{}┘{}\n", C_ICE, hline(INNER), C_RESET);

    let msgs: Vec<(u8, String)> = std::mem::take(&mut *FLASH.lock().unwrap_or_else(|e| e.into_inner()));
    for (lvl, m) in &msgs {
        let (c, s) = match *lvl {
            0 => (C_OK, S_OK),
            1 => (C_WARN, S_WARN),
            _ => (C_ERR, S_ERR),
        };
        println!("  {}{} {}{}", c, s, m, C_RESET);
    }
    if !msgs.is_empty() {
        println!();
    }
}

fn draw_divider(title: &str) {
    if title.is_empty() {
        println!("  {}{}{}", C_DIM, hline(INNER + 2), C_RESET);
    } else {
        let pad = (INNER + 2).saturating_sub(title.chars().count() + 6);
        println!(
            "  {}─── {}{}{} {}{}",
            C_ICE,
            C_BOLD,
            title,
            C_ICE,
            hline(pad),
            C_RESET
        );
    }
}

fn opt_line(key: &str, desc: &str) {
    println!("    {}[{}]{}  {}{}{}", C_NUM, key, C_RESET, C_WHITE, desc, C_RESET);
}

// Her menünün altında: sunucu kontrol paneli + gezinme ipuçları
fn footer(sub: bool) {
    println!();
    server_panel();
    println!();
    if sub {
        println!(
            "    {}[Tab]{} Ana Menü     {}[Backspace]{} Geri     {}[0]{} Geri",
            C_NUM, C_DIM, C_NUM, C_DIM, C_NUM, C_RESET
        );
    } else {
        println!("    {}[0]{} Çıkış (açık sunucular arka planda çalışmaya devam eder){}", C_NUM, C_DIM, C_RESET);
    }
    println!();
}

// ───────────────────────── Cihaz türleri ─────────────────────────

#[derive(Clone, Copy, PartialEq)]
enum Kind {
    Network,
    Spectrum,
    Generator,
}

const KINDS: [Kind; 3] = [Kind::Network, Kind::Spectrum, Kind::Generator];

impl Kind {
    fn id(&self) -> &'static str {
        match self {
            Kind::Network => "network",
            Kind::Spectrum => "spectrum",
            Kind::Generator => "generator",
        }
    }
    fn from_id(s: &str) -> Option<Kind> {
        match s {
            "network" => Some(Kind::Network),
            "spectrum" => Some(Kind::Spectrum),
            "generator" => Some(Kind::Generator),
            _ => None,
        }
    }
    fn key(&self) -> char {
        match self {
            Kind::Network => 'n',
            Kind::Spectrum => 's',
            Kind::Generator => 'g',
        }
    }
    fn name(&self) -> &'static str {
        match self {
            Kind::Network => "Network Analyzer",
            Kind::Spectrum => "Spectrum Analyzer",
            Kind::Generator => "Sinyal Jeneratörü",
        }
    }
    fn default_ip(&self) -> &'static str {
        match self {
            Kind::Network => "12.0.0.2",
            Kind::Spectrum => "12.0.0.3",
            Kind::Generator => "12.0.0.4",
        }
    }
    fn idn(&self) -> &'static str {
        match self {
            Kind::Network => "Keysight Technologies,N5222B,MY00000001,A.14.00",
            Kind::Spectrum => "Keysight Technologies,N9020B,MY00000002,A.20.00",
            Kind::Generator => "Keysight Technologies,N5182B,MY00000003,A.01.00",
        }
    }
    fn defaults(&self) -> Vec<(&'static str, &'static str)> {
        let mut v = vec![
            ("*IDN", self.idn()),
            ("*OPC", "1"),
            ("*ESR", "0"),
            ("*STB", "0"),
            ("*TST", "0"),
            ("*OPT", ""),
            ("SYST:ERR", "+0,\"No error\""),
        ];
        match self {
            Kind::Network => v.extend([
                ("SENS:FREQ:STAR", "+1.00000000E+007"),
                ("SENS:FREQ:STOP", "+2.65000000E+010"),
                ("SENS:SWE:POIN", "+201"),
                ("SENS:BAND", "+1.00000000E+003"),
                ("SOUR:POW", "-1.00000000E+001"),
                ("CALC:PAR:CAT", "\"CH1_S11_1,S11\""),
                ("INIT:CONT", "1"),
            ]),
            Kind::Spectrum => v.extend([
                ("FREQ:CENT", "+1.00000000E+009"),
                ("FREQ:SPAN", "+1.00000000E+008"),
                ("BAND", "+1.00000000E+006"),
                ("DISP:WIND:TRAC:Y:RLEV", "+0.00000000E+000"),
                ("CALC:MARK1:X", "+1.00000000E+009"),
                ("CALC:MARK1:Y", "-5.00000000E+001"),
            ]),
            Kind::Generator => v.extend([
                ("FREQ", "+1.00000000E+009"),
                ("POW", "-1.00000000E+001"),
                ("OUTP", "0"),
                ("OUTP:MOD", "0"),
            ]),
        }
        v
    }
}

// ───────────────────────── Dosya / IP / log yardımcıları ─────────────────────────

fn data_dir() -> PathBuf {
    let base = std::env::var("PROGRAMDATA").unwrap_or_else(|_| "C:\\ProgramData".into());
    let p = PathBuf::from(base).join("KeysightSim");
    let _ = fs::create_dir_all(&p);
    p
}
fn daemon_exe_path() -> PathBuf {
    data_dir().join("keysight_sim_daemon.exe")
}
fn pid_path(k: Kind) -> PathBuf {
    data_dir().join(format!("{}.pid", k.id()))
}
fn ip_conf_path(k: Kind) -> PathBuf {
    data_dir().join(format!("{}.ip", k.id()))
}
fn port_conf_path(k: Kind) -> PathBuf {
    data_dir().join(format!("{}.port", k.id()))
}
fn log_path(k: Kind) -> PathBuf {
    data_dir().join(format!("{}.log", k.id()))
}
fn responses_path(k: Kind) -> PathBuf {
    data_dir().join(format!("{}_responses.txt", k.id()))
}

fn prepare_daemon_exe() -> io::Result<PathBuf> {
    let current = std::env::current_exe()?;
    let target = daemon_exe_path();
    if current != target {
        let _ = fs::copy(&current, &target);
    }
    if target.exists() {
        Ok(target)
    } else {
        Ok(current)
    }
}

fn get_configured_ip(k: Kind) -> String {
    if let Ok(t) = fs::read_to_string(ip_conf_path(k)) {
        let ip = t.trim();
        if ip.parse::<Ipv4Addr>().is_ok() {
            return ip.to_string();
        }
    }
    k.default_ip().to_string()
}

fn set_configured_ip(k: Kind, ip: &str) {
    let _ = fs::write(ip_conf_path(k), ip.trim());
}

fn get_configured_port(k: Kind) -> u16 {
    fs::read_to_string(port_conf_path(k))
        .ok()
        .and_then(|t| t.trim().parse::<u16>().ok())
        .filter(|p| *p > 0)
        .unwrap_or(SCPI_PORT)
}

fn set_configured_port(k: Kind, port: u16) {
    let _ = fs::write(port_conf_path(k), port.to_string());
}

fn ensure_ip_on_system(ip: &str) {
    if ip.starts_with("127.") {
        return;
    }
    let _ = Command::new("netsh")
        .raw_arg(format!(
            "interface ipv4 add address \"Loopback Pseudo-Interface 1\" {} 255.255.255.255",
            ip
        ))
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status();
}

fn log(k: Kind, msg: &str) {
    if let Ok(mut f) = OpenOptions::new().create(true).append(true).open(log_path(k)) {
        let _ = writeln!(f, "{} {}", ts(), msg);
    }
}

fn ensure_responses_file(k: Kind) {
    let p = responses_path(k);
    if !p.exists() {
        let text = "# Özel cevaplar. Biçim:   SORGU=CEVAP   (sorgudaki ? işaretini yazmayın)\r\n\
# Bu dosya her sorguda yeniden okunur; kaydedince hemen geçerli olur.\r\n\
# Bu dosyadaki cevaplar, varsayılan ve hafızadaki değerlerden önceliklidir.\r\n\
# Örnekler:\r\n\
# *IDN=Üretici,Model,SeriNo,Sürüm\r\n\
# SENS:FREQ:STAR=+1.00000000E+006\r\n";
        let _ = fs::write(p, text);
    }
}

fn load_responses(k: Kind) -> Vec<(String, String)> {
    let raw = fs::read(responses_path(k)).unwrap_or_default();
    String::from_utf8_lossy(&raw)
        .lines()
        .filter_map(|l| {
            let l = l.trim();
            if l.is_empty() || l.starts_with('#') {
                return None;
            }
            let (a, b) = l.split_once('=')?;
            Some((a.trim().trim_end_matches('?').to_string(), b.trim().to_string()))
        })
        .collect()
}

fn current_idn(k: Kind) -> String {
    load_responses(k)
        .into_iter()
        .find(|(a, _)| a.trim_start_matches('*').eq_ignore_ascii_case("IDN"))
        .map(|(_, b)| b)
        .unwrap_or_else(|| k.idn().to_string())
}

// *IDN cevabını özel cevap dosyasına yazar (boş verilirse varsayılana döner)
fn set_idn(k: Kind, idn: &str) {
    ensure_responses_file(k);
    let raw = fs::read(responses_path(k)).unwrap_or_default();
    let text = String::from_utf8_lossy(&raw).to_string();
    let mut out: Vec<String> = text
        .lines()
        .filter(|l| !l.trim().to_uppercase().starts_with("*IDN"))
        .map(|s| s.to_string())
        .collect();
    if !idn.trim().is_empty() {
        out.push(format!("*IDN={}", idn.trim()));
    }
    let _ = fs::write(responses_path(k), out.join("\r\n") + "\r\n");
}

// ───────────────────────── SCPI sunucusu ─────────────────────────

struct State {
    store: Vec<(String, String)>,
    history: Vec<String>,
}

fn scpi_eq(a: &str, b: &str) -> bool {
    let a = a.trim().trim_start_matches(':').to_uppercase();
    let b = b.trim().trim_start_matches(':').to_uppercase();
    let sa: Vec<&str> = a.split(':').collect();
    let sb: Vec<&str> = b.split(':').collect();
    if sa.len() != sb.len() {
        return false;
    }
    sa.iter().zip(sb.iter()).all(|(x, y)| {
        x == y || (x.len() >= 3 && y.len() >= 3 && (x.starts_with(*y) || y.starts_with(*x)))
    })
}

fn answer(k: Kind, st: &State, responses: &[(String, String)], q: &str) -> String {
    if let Some((_, v)) = responses.iter().find(|(key, _)| scpi_eq(key, q)) {
        return v.clone();
    }
    if let Some((_, v)) = st.store.iter().find(|(key, _)| scpi_eq(key, q)) {
        return v.clone();
    }
    if let Some((_, v)) = k.defaults().iter().find(|(key, _)| scpi_eq(key, q)) {
        return v.to_string();
    }
    "0".to_string()
}

fn process(k: Kind, state: &Arc<Mutex<State>>, line: &str) -> Option<String> {
    let mut st = state.lock().unwrap_or_else(|e| e.into_inner());
    st.history.push(line.to_string());
    if st.history.len() > 10000 {
        st.history.remove(0);
    }
    let responses = load_responses(k);
    let mut out: Vec<String> = Vec::new();
    for part in line.split(';') {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }
        let (head, arg) = match part.find(char::is_whitespace) {
            Some(i) => (&part[..i], part[i..].trim()),
            None => (part, ""),
        };
        if let Some(q) = head.strip_suffix('?') {
            out.push(answer(k, &*st, &responses, q));
        } else if head.eq_ignore_ascii_case("*RST") {
            st.store.clear();
        } else if !head.starts_with('*') {
            if let Some(e) = st.store.iter_mut().find(|(key, _)| scpi_eq(key, head)) {
                e.1 = arg.to_string();
            } else {
                st.store.push((head.to_string(), arg.to_string()));
            }
        }
    }
    if out.is_empty() {
        None
    } else {
        Some(out.join(";"))
    }
}

fn handle_client(mut stream: TcpStream, k: Kind, state: Arc<Mutex<State>>) {
    let peer = stream.peer_addr().map(|a| a.to_string()).unwrap_or_default();
    log(k, &format!("[{}] bağlandı", peer));
    let _ = stream.set_nodelay(true);
    let clone = match stream.try_clone() {
        Ok(c) => c,
        Err(_) => return,
    };
    let mut reader = BufReader::new(clone);
    let mut buf: Vec<u8> = Vec::new();
    loop {
        buf.clear();
        match reader.read_until(b'\n', &mut buf) {
            Ok(0) | Err(_) => break,
            Ok(_) => {}
        }
        let line = String::from_utf8_lossy(&buf).trim().to_string();
        if line.is_empty() {
            continue;
        }
        log(k, &format!("[{}] GELEN : {}", peer, line));
        if let Some(r) = process(k, &state, &line) {
            log(k, &format!("[{}] CEVAP : {}", peer, r));
            if stream.write_all(format!("{}\n", r).as_bytes()).is_err() {
                break;
            }
        }
    }
    log(k, &format!("[{}] bağlantı kapandı", peer));
}

fn run_server(k: Kind, ip_str: &str, port: u16) {
    let _ = std::env::set_current_dir(data_dir());
    ensure_responses_file(k);
    ensure_ip_on_system(ip_str);
    let bind_ip: Ipv4Addr = match ip_str.parse() {
        Ok(ip) => ip,
        Err(e) => {
            log(k, &format!("Geçersiz IP {}: {}", ip_str, e));
            return;
        }
    };
    let listener = match TcpListener::bind((bind_ip, port)) {
        Ok(l) => l,
        Err(e) => {
            log(k, &format!("{}:{} açılamadı: {}", ip_str, port, e));
            return;
        }
    };
    let _ = fs::write(pid_path(k), format!("{} {} {}", std::process::id(), ip_str, port));
    log(k, &format!("Sunucu başladı -> {}:{}", ip_str, port));
    let state = Arc::new(Mutex::new(State {
        store: Vec::new(),
        history: Vec::new(),
    }));
    for s in listener.incoming() {
        if let Ok(s) = s {
            let st = Arc::clone(&state);
            thread::spawn(move || handle_client(s, k, st));
        }
    }
}

// ───────────────────────── Servis yönetimi ─────────────────────────

fn read_pid(k: Kind) -> Option<(u32, String, u16)> {
    let t = fs::read_to_string(pid_path(k)).ok()?;
    let mut it = t.split_whitespace();
    let pid: u32 = it.next()?.parse().ok()?;
    let second = it.next()?;
    if let Some(third) = it.next() {
        Some((pid, second.to_string(), third.parse().ok()?))
    } else {
        Some((pid, get_configured_ip(k), second.parse().ok()?))
    }
}

// Çalışan tüm süreç PID'lerini tek seferde alır (menüler hızlı çizilsin diye)
fn pid_set() -> HashSet<u32> {
    let out = match Command::new("tasklist").args(["/NH", "/FO", "CSV"]).output() {
        Ok(o) => o,
        Err(_) => return HashSet::new(),
    };
    String::from_utf8_lossy(&out.stdout)
        .lines()
        .filter_map(|l| {
            l.split("\",\"")
                .nth(1)
                .and_then(|p| p.trim_matches('"').trim().parse::<u32>().ok())
        })
        .collect()
}

fn is_running_with(k: Kind, set: &HashSet<u32>) -> Option<(u32, String, u16)> {
    let (pid, ip, port) = read_pid(k)?;
    if set.contains(&pid) {
        Some((pid, ip, port))
    } else {
        let _ = fs::remove_file(pid_path(k));
        None
    }
}

fn is_running(k: Kind) -> Option<(u32, String, u16)> {
    is_running_with(k, &pid_set())
}

fn start_service(k: Kind, ip: &str, port: u16) -> io::Result<()> {
    ensure_ip_on_system(ip);
    let exe = prepare_daemon_exe()?;
    const DETACHED: u32 = 0x0000_0008;
    const NEW_GROUP: u32 = 0x0000_0200;
    const NO_WINDOW: u32 = 0x0800_0000;
    const BREAKAWAY: u32 = 0x0100_0000;
    let spawn = |flags: u32| {
        Command::new(&exe)
            .current_dir(data_dir())
            .args(["--serve", k.id(), ip, &port.to_string()])
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .creation_flags(flags)
            .spawn()
    };
    if spawn(DETACHED | NEW_GROUP | NO_WINDOW | BREAKAWAY).is_err() {
        spawn(DETACHED | NEW_GROUP | NO_WINDOW)?;
    }
    Ok(())
}

fn stop_service(k: Kind) {
    if let Some((pid, _, _)) = is_running(k) {
        let _ = Command::new("taskkill")
            .raw_arg(format!("/PID {} /F", pid))
            .output();
        let _ = fs::remove_file(pid_path(k));
    }
}

fn stop_all_services() {
    for k in KINDS {
        stop_service(k);
    }
}

// Başlatır ve gerçekten ayağa kalkana kadar bekler
fn start_and_wait(k: Kind) -> Result<(u32, String, u16), String> {
    let ip = get_configured_ip(k);
    let port = get_configured_port(k);
    start_service(k, &ip, port).map_err(|e| e.to_string())?;
    for _ in 0..16 {
        thread::sleep(Duration::from_millis(250));
        if let Some(r) = is_running(k) {
            return Ok(r);
        }
    }
    Err(format!(
        "{} başlamadı: {}:{} başka bir program tarafından kullanılıyor olabilir.",
        k.name(),
        ip,
        port
    ))
}

fn start_with_flash(k: Kind) {
    match start_and_wait(k) {
        Ok((pid, ip, port)) => flash_ok(format!(
            "{} başlatıldı  ({}:{}  PID {})",
            k.name(),
            ip,
            port,
            pid
        )),
        Err(e) => flash_err(e),
    }
}

fn toggle_device(k: Kind) {
    if is_running(k).is_some() {
        stop_service(k);
        flash_ok(format!("{} durduruldu", k.name()));
    } else {
        start_with_flash(k);
    }
}

fn restart_device(k: Kind) {
    stop_service(k);
    thread::sleep(Duration::from_millis(700));
    start_with_flash(k);
}

// Her menüde çalışan kısayollar: n, s, g, a, k. İşlendiyse true döner.
fn global_key(c: char) -> bool {
    match c {
        'n' => toggle_device(Kind::Network),
        's' => toggle_device(Kind::Spectrum),
        'g' => toggle_device(Kind::Generator),
        'a' => {
            for k in KINDS {
                if is_running(k).is_none() {
                    start_with_flash(k);
                }
            }
        }
        'k' => {
            stop_all_services();
            flash_ok("Tüm sunucular durduruldu".to_string());
        }
        _ => return false,
    }
    true
}

// ───────────────────────── Konsol & PowerShell yardımcıları ─────────────────────────

fn is_admin() -> bool {
    let ok = |prog: &str| {
        Command::new(prog)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
            .map(|s| s.success())
            .unwrap_or(false)
    };
    ok("fltmc")
        || Command::new("net")
            .arg("session")
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
            .map(|s| s.success())
            .unwrap_or(false)
}

fn relaunch_as_admin() -> bool {
    let exe = match std::env::current_exe() {
        Ok(e) => e,
        Err(_) => return false,
    };
    let script = format!(
        "Start-Process -FilePath '{}' -Verb RunAs -ErrorAction Stop",
        ps_quote(&exe.to_string_lossy())
    );
    Command::new("powershell")
        .args(["-NoProfile", "-NonInteractive", "-Command", &script])
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

fn ps_quote(s: &str) -> String {
    s.replace('\'', "''")
}

fn ps(script: &str) -> String {
    let full = format!("[Console]::OutputEncoding=[Text.Encoding]::UTF8; {}", script);
    match Command::new("powershell")
        .args([
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            &full,
        ])
        .output()
    {
        Ok(o) => {
            let mut s = String::from_utf8_lossy(&o.stdout).to_string();
            let e = String::from_utf8_lossy(&o.stderr);
            if !e.trim().is_empty() {
                s.push_str(&e);
            }
            s
        }
        Err(e) => format!("PowerShell çalıştırılamadı: {}", e),
    }
}

// Komutu try/catch içinde çalıştırır; başarıyı / hatayı renkli yazdırır. Ek çıktıyı döndürür.
fn ps_report(script: &str, ok_msg: &str) -> String {
    let out = ps(&format!(
        "try {{ {}; '__OK__' }} catch {{ 'HATA: ' + $_.Exception.Message }}",
        script
    ));
    let extra = out.replace("__OK__", "").trim().to_string();
    if out.contains("__OK__") {
        println!("  {}{} {}{}", C_OK, S_OK, ok_msg, C_RESET);
    } else {
        println!("  {}{} {}{}", C_ERR, S_ERR, extra, C_RESET);
    }
    extra
}

fn netsh(args: String) {
    match Command::new("netsh").raw_arg(args).output() {
        Ok(o) => {
            let out = String::from_utf8_lossy(&o.stdout).trim().to_string();
            if !out.is_empty() {
                let col = if o.status.success() { C_OK } else { C_ERR };
                println!("  {}{}{}", col, out, C_RESET);
            }
            let e = String::from_utf8_lossy(&o.stderr).trim().to_string();
            if !e.is_empty() {
                println!("  {}{}{}", C_ERR, e, C_RESET);
            }
        }
        Err(e) => println!("  {}netsh çalıştırılamadı: {}{}", C_ERR, e, C_RESET),
    }
}

fn copy_clipboard(text: &str) -> bool {
    let mut c = match Command::new("clip")
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return false,
    };
    if let Some(mut si) = c.stdin.take() {
        let _ = si.write_all(text.as_bytes());
    }
    c.wait().map(|s| s.success()).unwrap_or(false)
}

// ───────────────────────── Sunucu kontrol paneli (her menünün altında) ─────────────────────────

fn state_badge_with(k: Kind, set: &HashSet<u32>) -> String {
    match is_running_with(k, set) {
        Some((pid, ip, port)) => format!(
            "{}● AKTİF{}   {}{}:{}{}  {}(PID {}){}",
            C_OK, C_RESET, C_ICE, ip, port, C_RESET, C_DIM, pid, C_RESET
        ),
        None => format!(
            "{}○ KAPALI{}  {}({}:{}){}",
            C_ERR,
            C_RESET,
            C_DIM,
            get_configured_ip(k),
            get_configured_port(k),
            C_RESET
        ),
    }
}

fn server_panel() {
    let set = pid_set();
    draw_divider("SUNUCU KONTROLÜ  •  her menüde geçerli");
    for k in KINDS {
        let running = is_running_with(k, &set).is_some();
        println!(
            "    {}[{}]{}  {}{:<18}{} {}{} {:<7}{} {}",
            C_NUM,
            k.key(),
            C_RESET,
            C_WHITE,
            k.name(),
            C_RESET,
            C_DIM,
            S_ARROW,
            if running { "kapat" } else { "başlat" },
            C_RESET,
            state_badge_with(k, &set)
        );
    }
    println!(
        "    {}[a]{} Tümünü Başlat        {}[k]{} Tümünü Durdur",
        C_NUM, C_RESET, C_NUM, C_RESET
    );
}

// ───────────────────────── 1) Sunucu kurma menüsü ─────────────────────────

fn colorize_log_line(line: &str) {
    if line.contains("GELEN :") {
        println!("  {}{}{}", C_ICE, line, C_RESET);
    } else if line.contains("CEVAP :") {
        println!("  {}{}{}", C_OK, line, C_RESET);
    } else {
        println!("  {}{}{}", C_FROST, line, C_RESET);
    }
}

fn live_view(k: Kind) {
    let path = log_path(k);
    let stop = Arc::new(AtomicBool::new(false));
    let s2 = Arc::clone(&stop);
    thread::spawn(move || {
        let _ = raw_key();
        s2.store(true, Ordering::SeqCst);
    });
    let raw = fs::read(&path).unwrap_or_default();
    let text = String::from_utf8_lossy(&raw).to_string();
    let lines: Vec<&str> = text.lines().collect();
    for l in &lines[lines.len().saturating_sub(15)..] {
        colorize_log_line(l);
    }
    let mut pos = raw.len() as u64;
    while !stop.load(Ordering::SeqCst) {
        thread::sleep(Duration::from_millis(200));
        if let Ok(mut f) = fs::File::open(&path) {
            let len = f.metadata().map(|m| m.len()).unwrap_or(0);
            if len < pos {
                pos = 0;
            }
            if len > pos {
                let _ = f.seek(SeekFrom::Start(pos));
                let mut buf = Vec::new();
                let _ = f.read_to_end(&mut buf);
                pos += buf.len() as u64;
                for l in String::from_utf8_lossy(&buf).lines() {
                    colorize_log_line(l);
                }
            }
        }
    }
}

fn open_device(k: Kind) {
    draw_header(&format!("CANLI SCPI İZLEME  ›  {}", k.name()));
    let (ip, port) = match is_running(k) {
        Some((pid, ip, port)) => {
            println!(
                "  {}{} Sunucu zaten çalışıyor (PID {}). Yeniden başlatılmadı.{}\n",
                C_OK, S_OK, pid, C_RESET
            );
            (ip, port)
        }
        None => match start_and_wait(k) {
            Ok((pid, ip, port)) => {
                println!(
                    "  {}{} Sunucu arka planda başlatıldı (PID {}).{}\n",
                    C_OK, S_OK, pid, C_RESET
                );
                (ip, port)
            }
            Err(e) => {
                println!("  {}{} {}{}", C_ERR, S_ERR, e, C_RESET);
                pause();
                return;
            }
        },
    };
    let visa_addr = format!("TCPIP0::{}::{}::SOCKET", ip, port);
    if copy_clipboard(&ip) {
        println!(
            "  {}Panoya kopyalandı:{} {}{}{}   {}(VISA: {}){}",
            C_FROST, C_RESET, C_NUM, ip, C_RESET, C_DIM, visa_addr, C_RESET
        );
    } else {
        println!(
            "  {}Adres:{} {}{}:{}   (VISA: {}){}",
            C_FROST, C_RESET, C_NUM, ip, port, visa_addr, C_RESET
        );
    }
    println!(
        "\n  {}Menüye dönmek için herhangi bir tuşa basın  (Sunucu arka planda çalışmaya devam eder){}",
        C_WARN, C_RESET
    );
    draw_divider("CANLI TRAFİK AKIŞI");
    live_view(k);
}

fn pick_device(prompt: &str) -> Pick<Kind> {
    loop {
        match read_key(prompt) {
            Key::Tab => return Pick::Home,
            Key::Back | Key::Esc => return Pick::Back,
            Key::Char(c) => match hot(c) {
                '1' | 'n' => return Pick::Got(Kind::Network),
                '2' | 's' => return Pick::Got(Kind::Spectrum),
                '3' | 'g' => return Pick::Got(Kind::Generator),
                '0' => return Pick::Back,
                _ => {}
            },
            _ => {}
        }
    }
}

macro_rules! pick {
    ($p:expr) => {
        match pick_device($p) {
            Pick::Got(k) => k,
            Pick::Back => continue,
            Pick::Home => return Nav::Home,
        }
    };
}

fn tcp_connect(ip: &str, port: u16) -> Result<TcpStream, String> {
    let addr: SocketAddr = format!("{}:{}", ip, port)
        .parse()
        .map_err(|e: std::net::AddrParseError| e.to_string())?;
    let s = TcpStream::connect_timeout(&addr, Duration::from_secs(2)).map_err(|e| e.to_string())?;
    let _ = s.set_read_timeout(Some(Duration::from_secs(2)));
    let _ = s.set_nodelay(true);
    Ok(s)
}

fn test_device(k: Kind) {
    println!();
    match is_running(k) {
        None => println!(
            "  {}{} {} çalışmıyor. Önce başlatın ({} tuşu).{}",
            C_WARN,
            S_WARN,
            k.name(),
            k.key(),
            C_RESET
        ),
        Some((_, ip, port)) => {
            let t0 = Instant::now();
            match tcp_connect(&ip, port) {
                Err(e) => println!("  {}{} Bağlanılamadı: {}{}", C_ERR, S_ERR, e, C_RESET),
                Ok(mut s) => {
                    let t_conn = t0.elapsed().as_millis();
                    let t1 = Instant::now();
                    let res = s
                        .write_all(b"*IDN?\n")
                        .map_err(|e| e.to_string())
                        .and_then(|_| {
                            let mut line = String::new();
                            let mut r = BufReader::new(s.try_clone().map_err(|e| e.to_string())?);
                            match r.read_line(&mut line) {
                                Ok(0) => Err("bağlantı kapandı".to_string()),
                                Ok(_) => Ok(line.trim().to_string()),
                                Err(e) => Err(e.to_string()),
                            }
                        });
                    match res {
                        Ok(r) => {
                            println!(
                                "  {}{} {}:{} bağlantı {} ms, cevap {} ms{}",
                                C_OK,
                                S_OK,
                                ip,
                                port,
                                t_conn,
                                t1.elapsed().as_millis(),
                                C_RESET
                            );
                            println!("  {}*IDN? {} {}{}", C_FROST, S_ARROW, r, C_RESET);
                        }
                        Err(e) => println!("  {}{} Sorgu başarısız: {}{}", C_ERR, S_ERR, e, C_RESET),
                    }
                }
            }
        }
    }
    println!();
    pause();
}

fn scpi_terminal(k: Kind) -> Nav {
    let (ip, port) = match is_running(k) {
        Some((_, ip, port)) => (ip, port),
        None => {
            flash_warn(format!("{} çalışmıyor; terminal için önce başlatın ({} tuşu).", k.name(), k.key()));
            return Nav::Back;
        }
    };
    let stream = match tcp_connect(&ip, port) {
        Ok(s) => s,
        Err(e) => {
            flash_err(format!("Bağlanılamadı: {}", e));
            return Nav::Back;
        }
    };
    let mut writer = match stream.try_clone() {
        Ok(w) => w,
        Err(e) => {
            flash_err(format!("Bağlantı hatası: {}", e));
            return Nav::Back;
        }
    };
    let mut reader = BufReader::new(stream);
    draw_header(&format!("SCPI TERMİNALİ  ›  {}  ({}:{})", k.name(), ip, port));
    println!(
        "  {}Komut yazıp Enter'a basın. '?' içeren komutlar cevap bekler (örn *IDN?  FREQ:CENT?).{}",
        C_FROST, C_RESET
    );
    println!(
        "  {}Çıkmak için boş satırda Backspace, ana menü için Tab.{}\n",
        C_DIM, C_RESET
    );
    loop {
        let cmd = match read_input("SCPI ›", None) {
            Input::Text(t) => t,
            Input::Home => return Nav::Home,
            _ => return Nav::Back,
        };
        if cmd.is_empty() {
            continue;
        }
        if writer.write_all(format!("{}\n", cmd).as_bytes()).is_err() {
            println!("  {}{} Bağlantı koptu.{}", C_ERR, S_ERR, C_RESET);
            pause();
            return Nav::Back;
        }
        if cmd.contains('?') {
            let mut line = String::new();
            match reader.read_line(&mut line) {
                Ok(0) => {
                    println!("  {}{} Sunucu bağlantıyı kapattı.{}", C_ERR, S_ERR, C_RESET);
                    pause();
                    return Nav::Back;
                }
                Ok(_) => println!("  {}{} {}{}", C_OK, S_ARROW, line.trim(), C_RESET),
                Err(_) => println!("  {}{} Cevap zaman aşımına uğradı.{}", C_WARN, S_WARN, C_RESET),
            }
        }
    }
}

fn devices_menu() -> Nav {
    loop {
        draw_header("SUNUCU KURMA  ›  Cihaz Sunucuları (SCPI / TCP soket)");
        let set = pid_set();
        draw_divider("CİHAZLAR");
        for (i, k) in KINDS.iter().enumerate() {
            println!(
                "    {}[{}]{}  {}{:<18}{}  {}",
                C_NUM,
                i + 1,
                C_RESET,
                C_WHITE,
                k.name(),
                C_RESET,
                state_badge_with(*k, &set)
            );
            println!("         {}*IDN: {}{}", C_DIM, current_idn(*k), C_RESET);
        }
        println!();
        draw_divider("ÇALIŞTIRMA");
        opt_line("1-3", "Cihazı başlat + IP'yi panoya kopyala + canlı trafiği izle");
        opt_line("r", "Cihazı yeniden başlat");
        opt_line("y", "Adresi panoya kopyala (IP ve VISA adresi)");
        draw_divider("AYARLAR");
        opt_line("i", "IP adresini değiştir");
        opt_line("p", "Port numarasını değiştir (varsayılan 5025)");
        opt_line("m", "Cihaz kimliğini (*IDN) değiştir");
        opt_line("e", "Özel SCPI cevap dosyasını düzenle (Notepad)");
        draw_divider("TEST & TANI");
        opt_line("t", "Bağlantı testi (*IDN? sorgusu, gecikme ölçümü)");
        opt_line("x", "SCPI terminali (komut gönder, cevap oku)");
        opt_line("l", "Günlüğü (log) Notepad'de aç");
        opt_line("c", "Günlüğü temizle");
        opt_line("f", "Güvenlik duvarı: portu gelen bağlantılara aç");
        opt_line("o", "Veri klasörünü aç");
        footer(true);

        let ch = match menu_key("Seçiminiz ›") {
            Mk::Home => return Nav::Home,
            Mk::Back => return Nav::Back,
            Mk::None => continue,
            Mk::Ch(c) => c,
        };
        match ch {
            '1' => open_device(Kind::Network),
            '2' => open_device(Kind::Spectrum),
            '3' => open_device(Kind::Generator),
            '0' => return Nav::Back,
            'r' => {
                let k = pick!("Hangi cihaz yeniden başlasın (1-3 / n s g) ›");
                restart_device(k);
            }
            'y' => {
                let k = pick!("Hangi cihazın adresi (1-3 / n s g) ›");
                let ip = get_configured_ip(k);
                let port = get_configured_port(k);
                if copy_clipboard(&ip) {
                    flash_ok(format!(
                        "Panoya kopyalandı: {}   (VISA: TCPIP0::{}::{}::SOCKET)",
                        ip, ip, port
                    ));
                } else {
                    flash_err("Panoya kopyalanamadı.".to_string());
                }
            }
            'i' => {
                let k = pick!("Hangi cihazın IP'si değişsin (1-3 / n s g) ›");
                let new_ip = ask!("Yeni IP adresi (örn 12.0.0.2) ›");
                if new_ip.parse::<Ipv4Addr>().is_ok() {
                    set_configured_ip(k, &new_ip);
                    if is_running(k).is_some() {
                        restart_device(k);
                    }
                    flash_ok(format!("{} IP adresi: {}", k.name(), new_ip));
                } else {
                    flash_err("Geçersiz IPv4 adresi.".to_string());
                }
            }
            'p' => {
                let k = pick!("Hangi cihazın portu değişsin (1-3 / n s g) ›");
                let v = ask!("Yeni port (1-65535) ›");
                match v.parse::<u16>() {
                    Ok(p) if p > 0 => {
                        set_configured_port(k, p);
                        if is_running(k).is_some() {
                            restart_device(k);
                        }
                        flash_ok(format!("{} portu: {}", k.name(), p));
                    }
                    _ => flash_err("Geçersiz port numarası.".to_string()),
                }
            }
            'm' => {
                let k = pick!("Hangi cihazın kimliği değişsin (1-3 / n s g) ›");
                println!("  {}Şu an: {}{}", C_DIM, current_idn(k), C_RESET);
                let v = ask!("Yeni *IDN (Üretici,Model,SeriNo,Sürüm; boş = varsayılan) ›");
                set_idn(k, &v);
                flash_ok(format!("{} kimliği güncellendi (hemen geçerli).", k.name()));
            }
            'e' => {
                let k = pick!("Hangi cihaz (1-3 / n s g) ›");
                ensure_responses_file(k);
                let _ = Command::new("notepad").arg(responses_path(k)).spawn();
            }
            't' => {
                let k = pick!("Hangi cihaz test edilsin (1-3 / n s g) ›");
                test_device(k);
            }
            'x' => {
                let k = pick!("Hangi cihaza bağlanılsın (1-3 / n s g) ›");
                if scpi_terminal(k) == Nav::Home {
                    return Nav::Home;
                }
            }
            'l' => {
                let k = pick!("Hangi cihazın günlüğü (1-3 / n s g) ›");
                if !log_path(k).exists() {
                    let _ = fs::write(log_path(k), "");
                }
                let _ = Command::new("notepad").arg(log_path(k)).spawn();
            }
            'c' => {
                let k = pick!("Hangi cihazın günlüğü temizlensin (1-3 / n s g) ›");
                let _ = fs::write(log_path(k), "");
                flash_ok(format!("{} günlüğü temizlendi.", k.name()));
            }
            'f' => {
                let k = pick!("Hangi cihazın portu açılsın (1-3 / n s g) ›");
                let port = get_configured_port(k);
                let name = format!("MultiTool SCPI {}", port);
                println!();
                netsh(format!("advfirewall firewall delete rule name=\"{}\"", name));
                netsh(format!(
                    "advfirewall firewall add rule name=\"{}\" dir=in action=allow protocol=TCP localport={}",
                    name, port
                ));
                println!();
                pause();
            }
            'o' => {
                let _ = Command::new("explorer").arg(data_dir()).spawn();
            }
            _ => {}
        }
    }
}

// ───────────────────────── Ethernet adaptörleri (2, 3) ─────────────────────────

#[derive(Clone)]
struct Adapter {
    name: String,
    status: String,
    speed: String,
    ips: String,
}

fn list_adapters() -> Vec<Adapter> {
    let script = "Get-NetAdapter -Physical | ForEach-Object { $a=$_; \
        $ips=(Get-NetIPAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | \
        ForEach-Object { $_.IPAddress + '/' + $_.PrefixLength }) -join ', '; \
        '{0}|{1}|{2}|{3}' -f $a.Name,$a.Status,$a.LinkSpeed,$ips }";
    ps(script)
        .lines()
        .filter_map(|l| {
            let p: Vec<&str> = l.trim().splitn(4, '|').collect();
            if p.len() == 4 {
                Some(Adapter {
                    name: p[0].to_string(),
                    status: p[1].to_string(),
                    speed: p[2].to_string(),
                    ips: p[3].to_string(),
                })
            } else {
                None
            }
        })
        .collect()
}

fn adapter_link(name: &str) -> String {
    ps(&format!("(Get-NetAdapter -Name '{}').LinkSpeed", ps_quote(name)))
        .trim()
        .to_string()
}

fn status_color(st: &str) -> &'static str {
    if st.eq_ignore_ascii_case("Up") {
        C_OK
    } else if st.eq_ignore_ascii_case("Disabled") {
        C_ERR
    } else {
        C_WARN
    }
}

fn print_adapter_state(a: &Adapter) {
    println!(
        "    {}{}{}   {}[{}{}{} / {}{}{}]{}",
        C_BOLD,
        a.name,
        C_RESET,
        C_FROST,
        status_color(&a.status),
        a.status,
        C_FROST,
        C_ICE,
        a.speed,
        C_FROST,
        C_RESET
    );
    println!(
        "         {}IP:{} {}{}{}",
        C_DIM,
        C_RESET,
        C_WHITE,
        if a.ips.is_empty() { "Atanmamış (-)" } else { a.ips.as_str() },
        C_RESET
    );
}

const NO_HOT: &[char] = &[];

fn pick_adapter(title: &str) -> Pick<Adapter> {
    draw_header(title);
    println!("  {}Adaptörler taranıyor...{}", C_FROST, C_RESET);
    let ads = list_adapters();
    if ads.is_empty() {
        flash_err("Fiziksel ağ adaptörü bulunamadı.".to_string());
        return Pick::Back;
    }
    loop {
        draw_header(title);
        draw_divider("AĞ ADAPTÖRLERİ");
        for (i, a) in ads.iter().enumerate() {
            print!("    {}[{}]{}", C_NUM, i + 1, C_RESET);
            print_adapter_state(a);
        }
        footer(true);
        match read_input("Adaptör No ›", Some(NO_HOT)) {
            Input::Text(t) => {
                if let Ok(n) = t.parse::<usize>() {
                    if n == 0 {
                        return Pick::Back;
                    }
                    if n <= ads.len() {
                        return Pick::Got(ads[n - 1].clone());
                    }
                }
            }
            Input::Hot(c) => {
                global_key(c);
            }
            Input::Back => return Pick::Back,
            Input::Home => return Pick::Home,
        }
    }
}

fn mask_from(input: &str) -> Option<String> {
    if let Ok(m) = input.parse::<Ipv4Addr>() {
        return Some(m.to_string());
    }
    let p: u32 = input.trim_start_matches('/').parse().ok()?;
    if p > 32 {
        return None;
    }
    let m: u32 = if p == 0 { 0 } else { u32::MAX << (32 - p) };
    Some(Ipv4Addr::from(m).to_string())
}

fn parse_cidr(s: &str) -> Option<(String, String)> {
    let (ip, pre) = match s.trim().split_once('/') {
        Some((a, b)) => (a.trim(), b.trim()),
        None => (s.trim(), "24"),
    };
    let ip: Ipv4Addr = ip.parse().ok()?;
    Some((ip.to_string(), mask_from(pre)?))
}

fn set_dns(name: &str, list: &str) {
    let ips: Vec<&str> = list
        .split(|c: char| c == ',' || c == ';' || c.is_whitespace())
        .map(|s| s.trim())
        .filter(|s| !s.is_empty())
        .collect();
    if ips.is_empty() {
        netsh(format!("interface ipv4 set dnsservers name=\"{}\" source=dhcp", name));
        return;
    }
    if ips.iter().any(|s| s.parse::<Ipv4Addr>().is_err()) {
        println!("  {}{} Geçersiz DNS adresi.{}", C_ERR, S_ERR, C_RESET);
        return;
    }
    netsh(format!(
        "interface ipv4 set dnsservers name=\"{}\" static {} primary validate=no",
        name, ips[0]
    ));
    for (i, d) in ips.iter().enumerate().skip(1) {
        netsh(format!(
            "interface ipv4 add dnsservers name=\"{}\" address={} index={} validate=no",
            name,
            d,
            i + 1
        ));
    }
}

fn valid_host(s: &str) -> bool {
    !s.is_empty() && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '.' || c == '-' || c == ':')
}

fn adapter_details(name: &str) -> String {
    let script = r#"
$n = '%N%'
$a = Get-NetAdapter -Name $n -ErrorAction SilentlyContinue
if (-not $a) { 'Adaptör bulunamadı.'; return }
$i = Get-NetIPInterface -InterfaceAlias $n -AddressFamily IPv4 -ErrorAction SilentlyContinue
$c = Get-NetIPConfiguration -InterfaceAlias $n -ErrorAction SilentlyContinue
'Açıklama        : ' + $a.InterfaceDescription
'MAC adresi      : ' + $a.MacAddress
'Durum           : ' + $a.Status
'Bağlantı hızı   : ' + $a.LinkSpeed
'Sürücü sürümü   : ' + $a.DriverVersionString
'MTU             : ' + $i.NlMtu
'DHCP            : ' + $i.Dhcp
'Ağ geçidi       : ' + ((@($c.IPv4DefaultGateway.NextHop)) -join ', ')
'DNS             : ' + ((@($c.DnsServer.ServerAddresses)) -join ', ')
"#;
    ps(&script.replace("%N%", &ps_quote(name)))
}

fn adapter_ip_menu(mut a: Adapter) -> Nav {
    let mut refresh = false;
    loop {
        if refresh {
            if let Some(n) = list_adapters().into_iter().find(|x| x.name == a.name) {
                a = n;
            }
            refresh = false;
        }
        draw_header(&format!("ETHERNET IP  ›  {}", a.name));
        draw_divider("MEVCUT DURUM");
        print_adapter_state(&a);
        println!();
        draw_divider("IP & AĞ İŞLEMLERİ");
        opt_line("1", "Statik IP ata (mevcut IP'leri değiştirir; ağ geçidi + DNS isteğe bağlı)");
        opt_line("2", "Ek IP(ler) ekle (çoklu IP / multi-homing)");
        opt_line("3", "Belirli bir IP adresini sil");
        opt_line("4", "DHCP (otomatik IP + otomatik DNS) moduna geçir");
        opt_line("5", "DNS sunucularını ayarla (boş = otomatik)");
        opt_line("6", "MTU ayarla (Jumbo Frame için 9000)");
        opt_line("7", "Adaptörü etkinleştir / devre dışı bırak");
        opt_line("8", "Adaptörü yeniden başlat");
        opt_line("9", "Ping testi");
        opt_line("d", "Ayrıntılı bilgi (MAC, sürücü, MTU, DNS, ağ geçidi)");
        footer(true);

        let ch = match menu_key("Seçiminiz ›") {
            Mk::Home => return Nav::Home,
            Mk::Back => return Nav::Back,
            Mk::None => continue,
            Mk::Ch(c) => c,
        };
        let n = a.name.clone();
        let q = ps_quote(&n);
        match ch {
            '0' => return Nav::Back,
            '1' => {
                let ip = ask!("IP Adresi (örn 192.168.1.10/24) ›");
                match parse_cidr(&ip) {
                    Some((ip, mask)) => {
                        let gw = ask!("Ağ Geçidi (boş geçilebilir) ›");
                        let gw_arg = if gw.parse::<Ipv4Addr>().is_ok() {
                            format!(" {}", gw)
                        } else {
                            if !gw.is_empty() {
                                println!("  {}{} Ağ geçidi geçersiz, atlandı.{}", C_WARN, S_WARN, C_RESET);
                            }
                            String::new()
                        };
                        netsh(format!(
                            "interface ipv4 set address name=\"{}\" static {} {}{}",
                            n, ip, mask, gw_arg
                        ));
                        let dns = ask!("DNS sunucuları, virgülle (boş = değiştirme) ›");
                        if !dns.is_empty() {
                            set_dns(&n, &dns);
                        }
                    }
                    None => println!("  {}{} Geçersiz IP formatı.{}", C_ERR, S_ERR, C_RESET),
                }
                refresh = true;
                pause();
            }
            '2' => {
                let inp = ask!("IP'ler, virgülle (örn 10.0.0.5/8, 192.168.2.20/24) ›");
                for item in inp.split(',').filter(|s| !s.trim().is_empty()) {
                    match parse_cidr(item) {
                        Some((ip, mask)) => {
                            println!("  {}{} Ekleniyor: {} / {}{}", C_ICE, S_ARROW, ip, mask, C_RESET);
                            netsh(format!(
                                "interface ipv4 add address name=\"{}\" address={} mask={}",
                                n, ip, mask
                            ));
                        }
                        None => println!("  {}{} Geçersiz: {}{}", C_ERR, S_ERR, item.trim(), C_RESET),
                    }
                }
                refresh = true;
                pause();
            }
            '3' => {
                let ip = ask!("Silinecek IP ›");
                match ip.parse::<Ipv4Addr>() {
                    Ok(ip) => netsh(format!(
                        "interface ipv4 delete address name=\"{}\" address={}",
                        n, ip
                    )),
                    Err(_) => println!("  {}{} Geçersiz IP.{}", C_ERR, S_ERR, C_RESET),
                }
                refresh = true;
                pause();
            }
            '4' => {
                netsh(format!("interface ipv4 set address name=\"{}\" source=dhcp", n));
                netsh(format!("interface ipv4 set dnsservers name=\"{}\" source=dhcp", n));
                refresh = true;
                pause();
            }
            '5' => {
                let dns = ask!("DNS sunucuları, virgülle (örn 8.8.8.8, 1.1.1.1; boş = otomatik) ›");
                set_dns(&n, &dns);
                pause();
            }
            '6' => {
                let v = ask!("MTU değeri (576-9216; örn 1500 / 9000) ›");
                match v.parse::<u32>() {
                    Ok(m) if (576..=9216).contains(&m) => {
                        netsh(format!(
                            "interface ipv4 set subinterface \"{}\" mtu={} store=persistent",
                            n, m
                        ));
                        println!(
                            "  {}Not: Jumbo Frame için sürücüde 'Jumbo Packet' ayarı da açık olmalı.{}",
                            C_DIM, C_RESET
                        );
                    }
                    _ => println!("  {}{} Geçersiz MTU.{}", C_ERR, S_ERR, C_RESET),
                }
                pause();
            }
            '7' => {
                if a.status.eq_ignore_ascii_case("Disabled") {
                    ps_report(
                        &format!("Enable-NetAdapter -Name '{}' -Confirm:$false -ErrorAction Stop", q),
                        "Adaptör etkinleştirildi.",
                    );
                } else if confirm("Adaptör devre dışı bırakılsın mı? Bağlantı kopar. (e/h) ›") {
                    ps_report(
                        &format!("Disable-NetAdapter -Name '{}' -Confirm:$false -ErrorAction Stop", q),
                        "Adaptör devre dışı bırakıldı.",
                    );
                }
                refresh = true;
                pause();
            }
            '8' => {
                println!("  {}Yeniden başlatılıyor (bağlantı kısa süre kopar)...{}", C_WARN, C_RESET);
                ps_report(
                    &format!("Restart-NetAdapter -Name '{}' -Confirm:$false -ErrorAction Stop", q),
                    "Adaptör yeniden başlatıldı.",
                );
                refresh = true;
                pause();
            }
            '9' => {
                let t = ask!("Ping hedefi (IP veya ad) ›");
                if valid_host(&t) {
                    println!("  {}Ping gönderiliyor...{}", C_FROST, C_RESET);
                    match Command::new("ping").args(["-n", "4", &t]).output() {
                        Ok(o) => {
                            for l in String::from_utf8_lossy(&o.stdout).lines() {
                                if !l.trim().is_empty() {
                                    println!("  {}{}{}", C_FROST, l, C_RESET);
                                }
                            }
                        }
                        Err(e) => println!("  {}{} ping çalışmadı: {}{}", C_ERR, S_ERR, e, C_RESET),
                    }
                } else {
                    println!("  {}{} Geçersiz hedef.{}", C_ERR, S_ERR, C_RESET);
                }
                pause();
            }
            'd' => {
                println!("  {}Bilgiler okunuyor...{}", C_FROST, C_RESET);
                for l in adapter_details(&n).lines() {
                    println!("  {}{}{}", C_WHITE, l, C_RESET);
                }
                pause();
            }
            _ => {}
        }
    }
}

fn ip_menu() -> Nav {
    loop {
        let a = match pick_adapter("ETHERNET AYARI  ›  IP Yapılandırması") {
            Pick::Got(a) => a,
            Pick::Back => return Nav::Back,
            Pick::Home => return Nav::Home,
        };
        if adapter_ip_menu(a) == Nav::Home {
            return Nav::Home;
        }
    }
}

// ───────────────────────── Ethernet hız & duplex (dinamik liste) ─────────────────────────

struct SpeedOpt {
    reg: String,
    display: String,
    mbps: Option<u64>,
    is_auto: bool,
    half: bool,
}

struct SpeedInfo {
    keyword: String,
    prop_name: String,
    cur_reg: String,
    cur_display: String,
    opts: Vec<SpeedOpt>,
}

// "2.5 Gbps Full Duplex", "1,0 Gbps Tam Dupleks", "100 Mbps", "10Gbps" gibi metinlerden hızı (Mbps) çıkarır
fn parse_mbps(s: &str) -> Option<u64> {
    let s = s.replace(',', ".");
    let toks: Vec<&str> = s.split_whitespace().collect();
    for (i, t) in toks.iter().enumerate() {
        let num_end = t
            .find(|c: char| !(c.is_ascii_digit() || c == '.'))
            .unwrap_or(t.len());
        if num_end == 0 {
            continue;
        }
        let num: f64 = match t[..num_end].parse() {
            Ok(n) => n,
            Err(_) => continue,
        };
        let unit = if num_end < t.len() {
            t[num_end..].to_lowercase()
        } else {
            toks.get(i + 1).map(|x| x.to_lowercase()).unwrap_or_default()
        };
        if unit.starts_with('g') {
            return Some((num * 1000.0).round() as u64);
        }
        if unit.starts_with('m') {
            return Some(num.round() as u64);
        }
    }
    None
}

fn fmt_speed(m: u64) -> String {
    if m >= 1000 {
        if m % 1000 == 0 {
            format!("{} Gbps", m / 1000)
        } else {
            format!("{:.1} Gbps", m as f64 / 1000.0)
        }
    } else {
        format!("{} Mbps", m)
    }
}

fn speed_class(max_mbps: u64) -> &'static str {
    match max_mbps {
        0 => "Bilinmiyor",
        1..=100 => "Fast Ethernet (100 Mbps sınıfı)",
        101..=1000 => "Gigabit Ethernet (1 Gbps sınıfı)",
        1001..=2500 => "Multi-Gig 2.5G sınıfı",
        2501..=5000 => "Multi-Gig 5G sınıfı",
        5001..=10000 => "10 Gigabit Ethernet sınıfı",
        _ => "10G üzeri (SFP+ / 25G / 40G sınıfı)",
    }
}

// Sürücünün gerçekten sunduğu hız seçeneklerini okur (sabit liste YOK)
fn fetch_speed_info(name: &str) -> Option<SpeedInfo> {
    let script = r#"
$n = '%N%'
$all = Get-NetAdapterAdvancedProperty -Name $n -ErrorAction SilentlyContinue
$p = $all | Where-Object { $_.RegistryKeyword -eq '*SpeedDuplex' } | Select-Object -First 1
if (-not $p) {
  $p = $all | Where-Object {
    $_.RegistryKeyword -in 'SpeedDuplex','LinkSpeedDuplex','ConnectionType','Speed' -or
    $_.DisplayName -match 'Speed.*Duplex|Duplex|Dupleks'
  } | Select-Object -First 1
}
if ($p) {
  'KEY|' + $p.RegistryKeyword + '|' + $p.DisplayName + '|' + (($p.RegistryValue) -join '') + '|' + $p.DisplayValue
  $rv = @($p.ValidRegistryValues)
  $dv = @($p.ValidDisplayValues)
  for ($i = 0; $i -lt $rv.Count; $i++) { 'OPT|' + $rv[$i] + '|' + $dv[$i] }
}
"#;
    let out = ps(&script.replace("%N%", &ps_quote(name)));
    let mut keyword = String::new();
    let mut prop_name = String::new();
    let mut cur_reg = String::new();
    let mut cur_display = String::new();
    let mut opts: Vec<SpeedOpt> = Vec::new();
    for l in out.lines() {
        let l = l.trim();
        if let Some(rest) = l.strip_prefix("KEY|") {
            let p: Vec<&str> = rest.splitn(4, '|').collect();
            if p.len() == 4 {
                keyword = p[0].to_string();
                prop_name = p[1].to_string();
                cur_reg = p[2].to_string();
                cur_display = p[3].to_string();
            }
        } else if let Some(rest) = l.strip_prefix("OPT|") {
            let p: Vec<&str> = rest.splitn(2, '|').collect();
            if p.len() == 2 {
                let disp = p[1].to_string();
                let low = disp.to_lowercase();
                let mbps = parse_mbps(&disp);
                opts.push(SpeedOpt {
                    reg: p[0].to_string(),
                    is_auto: low.contains("auto") || low.contains("otomatik") || (mbps.is_none() && p[0] == "0"),
                    half: low.contains("half") || low.contains("yar"),
                    mbps,
                    display: disp,
                });
            }
        }
    }
    if keyword.is_empty() || opts.is_empty() {
        return None;
    }
    // Otomatik en başta, sonra hızına göre; aynı hızda önce half sonra full
    opts.sort_by_key(|o| (if o.is_auto { 0u8 } else { 1u8 }, o.mbps.unwrap_or(0), if o.half { 0u8 } else { 1u8 }));
    Some(SpeedInfo {
        keyword,
        prop_name,
        cur_reg,
        cur_display,
        opts,
    })
}

const SPEED_HOT: &[char] = &['r', 'l'];

fn speed_adapter_menu(a: &Adapter) -> Nav {
    draw_header(&format!("HIZ & DUPLEX  ›  {}", a.name));
    println!("  {}Sürücüden hız seçenekleri okunuyor...{}", C_FROST, C_RESET);
    let mut info = fetch_speed_info(&a.name);
    let mut link = a.speed.clone();
    let q = ps_quote(&a.name);
    loop {
        draw_header(&format!("HIZ & DUPLEX  ›  {}", a.name));
        draw_divider("BAĞLANTI BİLGİSİ");
        println!("    {}Mevcut bağlantı hızı :{} {}{}{}", C_DIM, C_RESET, C_ICE, link, C_RESET);
        match &info {
            None => {
                println!(
                    "\n  {}{} Bu adaptörün sürücüsü hız/duplex seçeneği sunmuyor (sanal ya da özel sürücü olabilir).{}",
                    C_WARN, S_WARN, C_RESET
                );
                println!(
                    "  {}Sürücünün sunduğu tüm gelişmiş özellikleri [l] ile listeleyebilirsiniz.{}\n",
                    C_DIM, C_RESET
                );
            }
            Some(si) => {
                let max = si.opts.iter().filter_map(|o| o.mbps).max().unwrap_or(0);
                println!(
                    "    {}Desteklenen en yüksek :{} {}{}{}  {}({}){}",
                    C_DIM,
                    C_RESET,
                    C_NUM,
                    if max > 0 { fmt_speed(max) } else { "?".to_string() },
                    C_RESET,
                    C_FROST,
                    speed_class(max),
                    C_RESET
                );
                println!(
                    "    {}Ayar özelliği        :{} {}  {}({}){}",
                    C_DIM, C_RESET, si.prop_name, C_DIM, si.keyword, C_RESET
                );
                println!(
                    "    {}Seçili ayar          :{} {}{}{}\n",
                    C_DIM, C_RESET, C_WHITE, si.cur_display, C_RESET
                );
                draw_divider("UYGULANABİLİR HIZ AYARLARI  (sürücüden okundu)");
                for (i, o) in si.opts.iter().enumerate() {
                    let is_cur = o.reg == si.cur_reg;
                    let col = if o.mbps.map(|m| m >= 2500).unwrap_or(false) { C_ICE } else { C_WHITE };
                    println!(
                        "    {}[{:>2}]{}  {}{:<34}{} {}{}{}",
                        C_NUM,
                        i + 1,
                        C_RESET,
                        col,
                        o.display,
                        C_RESET,
                        if is_cur { C_OK } else { C_DIM },
                        if is_cur { "◄ MEVCUT".to_string() } else { format!("(değer {})", o.reg) },
                        C_RESET
                    );
                }
                println!();
            }
        }
        opt_line("r", "Yeniden oku / bağlantı hızını yenile");
        opt_line("l", "Sürücünün tüm gelişmiş özelliklerini listele");
        footer(true);

        match read_input("Ayar No veya komut ›", Some(SPEED_HOT)) {
            Input::Home => return Nav::Home,
            Input::Back => return Nav::Back,
            Input::Hot(c) => {
                if global_key(c) {
                    continue;
                }
                match c {
                    'r' => {
                        println!("  {}Okunuyor...{}", C_FROST, C_RESET);
                        info = fetch_speed_info(&a.name);
                        link = adapter_link(&a.name);
                    }
                    'l' => {
                        println!("  {}Okunuyor...{}", C_FROST, C_RESET);
                        let t = ps(&format!(
                            "Get-NetAdapterAdvancedProperty -Name '{}' | ForEach-Object {{ $_.DisplayName + '  =  ' + $_.DisplayValue }}",
                            q
                        ));
                        for l in t.lines().filter(|l| !l.trim().is_empty()) {
                            println!("  {}{}{}", C_FROST, l.trim(), C_RESET);
                        }
                        pause();
                    }
                    _ => {}
                }
            }
            Input::Text(t) => {
                let n: usize = match t.parse() {
                    Ok(n) => n,
                    Err(_) => continue,
                };
                if n == 0 {
                    return Nav::Back;
                }
                let (kw, reg, disp) = match &info {
                    Some(si) if n <= si.opts.len() => (
                        si.keyword.clone(),
                        si.opts[n - 1].reg.clone(),
                        si.opts[n - 1].display.clone(),
                    ),
                    _ => continue,
                };
                println!(
                    "\n  {}Uygulanıyor: {}  (bağlantı kısa süre kopup gelebilir)...{}",
                    C_WARN, disp, C_RESET
                );
                let script = format!(
                    "try {{ Set-NetAdapterAdvancedProperty -Name '{n}' -RegistryKeyword '{kw}' -RegistryValue '{rv}' -ErrorAction Stop; \
                     Start-Sleep -Seconds 4; 'LINK=' + (Get-NetAdapter -Name '{n}').LinkSpeed; '__OK__' }} \
                     catch {{ 'HATA: ' + $_.Exception.Message }}",
                    n = q,
                    kw = ps_quote(&kw),
                    rv = ps_quote(&reg)
                );
                let out = ps(&script);
                if out.contains("__OK__") {
                    if let Some(l) = out.lines().find_map(|l| l.trim().strip_prefix("LINK=")) {
                        link = l.trim().to_string();
                    }
                    println!(
                        "  {}{} Uygulandı. Bağlantı hızı: {}{}",
                        C_OK, S_OK, link, C_RESET
                    );
                    println!(
                        "  {}Hız anlaşması uzun sürebilir; güncel değer için [r] tuşuna basın.{}",
                        C_DIM, C_RESET
                    );
                    info = fetch_speed_info(&a.name);
                } else {
                    println!("  {}{} {}{}", C_ERR, S_ERR, out.trim(), C_RESET);
                }
                pause();
            }
        }
    }
}

fn speed_menu() -> Nav {
    loop {
        let a = match pick_adapter("ETHERNET AYARI  ›  Hız & Duplex") {
            Pick::Got(a) => a,
            Pick::Back => return Nav::Back,
            Pick::Home => return Nav::Home,
        };
        if speed_adapter_menu(&a) == Nav::Home {
            return Nav::Home;
        }
    }
}

// ───────────────────────── 4) USB panel kontrolü ─────────────────────────

struct UsbDisplayItem {
    group: String,
    status: String,
    title: String,
    meta: String,
    instance_id: String,
    letters: String, // "E:,F:" gibi sürücü harfleri (yalnızca bellekler)
}

fn fetch_usb_items(show_hubs: bool) -> Vec<UsbDisplayItem> {
    let script = r#"
$out = @()
Get-Disk | Where-Object { $_.BusType -eq 'USB' } | ForEach-Object {
    $d = $_
    $size = "{0:N1} GB" -f ($d.Size / 1GB)
    $parts = Get-Partition -DiskNumber $d.Number -ErrorAction SilentlyContinue
    $lets = @()
    $vols = @()
    if ($parts) {
        foreach ($p in $parts) {
            if ($p.DriveLetter) {
                $lets += "$($p.DriveLetter):"
                $v = Get-Volume -DriveLetter $p.DriveLetter -ErrorAction SilentlyContinue
                if ($v -and $v.FileSystemLabel) { $vols += $v.FileSystemLabel }
            }
        }
    }
    $letStr = if ($lets.Count -gt 0) { $lets -join ', ' } else { 'Harf Yok' }
    $volStr = if ($vols.Count -gt 0) { " [$($vols -join ', ')]" } else { '' }
    $pnp = Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object {
        $_.Class -eq 'DiskDrive' -and $_.FriendlyName -eq $d.FriendlyName
    } | Select-Object -First 1
    $iid = if ($pnp) { $pnp.InstanceId } else { $d.Path }
    $st = if ($pnp) { $pnp.Status } else { $d.HealthStatus }
    $out += "BELLEK|$st|$($d.FriendlyName)$volStr|$letStr  •  $size|$iid|$($lets -join ',')"
}

Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object {
    ($_.InstanceId -like 'USB\*' -or $_.Class -eq 'USB') -and $_.Class -ne 'DiskDrive'
} | ForEach-Object {
    $fn = $_.FriendlyName
    if (-not $fn) { $fn = $_.Name }
    $isHub = ($fn -match 'Root Hub|Host Controller|Generic USB Hub|Composite Device|Kök Hub|Ana Denetleyici|Bileşik Aygıt|USB Mass Storage Device|USB Yığın Depolama')
    $grp = if ($isHub) { 'HUB' } else { 'AYGIT' }
    $vid = if ($_.InstanceId -match 'VID_([0-9A-F]{4})&PID_([0-9A-F]{4})') { "VID:$($matches[1]) PID:$($matches[2])" } else { $_.Class }
    $out += "$grp|$($_.Status)|$fn|$vid|$($_.InstanceId)|"
}
$out -join "`n"
"#;

    let mut list = Vec::new();
    for line in ps(script).lines() {
        let p: Vec<&str> = line.trim().splitn(6, '|').collect();
        if p.len() == 6 {
            let grp = p[0].to_string();
            if grp == "HUB" && !show_hubs {
                continue;
            }
            list.push(UsbDisplayItem {
                group: grp,
                status: p[1].to_string(),
                title: p[2].to_string(),
                meta: p[3].to_string(),
                instance_id: p[4].to_string(),
                letters: p[5].to_string(),
            });
        }
    }
    list
}

// ── USB sistem ayarları (kayıt defteri / güç planı) ──

const USB_SUB: &str = "2a737441-1930-4402-8d77-b2bebba308a3";
const USB_SELECTIVE: &str = "48e6b7a6-50f5-4782-a5d4-53bb8f07e226";
const KEY_USBSTOR: &str = "HKLM\\SYSTEM\\CurrentControlSet\\Services\\USBSTOR";
const KEY_WPROTECT: &str = "HKLM\\SYSTEM\\CurrentControlSet\\Control\\StorageDevicePolicies";

fn reg_dword(key: &str, name: &str) -> Option<u32> {
    let o = Command::new("reg")
        .raw_arg(format!("query \"{}\" /v {}", key, name))
        .output()
        .ok()?;
    if !o.status.success() {
        return None;
    }
    let t = String::from_utf8_lossy(&o.stdout).to_string();
    for l in t.lines() {
        if let Some(pos) = l.find("0x") {
            return u32::from_str_radix(l[pos + 2..].trim(), 16).ok();
        }
    }
    None
}

fn reg_set_dword(key: &str, name: &str, val: u32) -> bool {
    Command::new("reg")
        .raw_arg(format!("add \"{}\" /v {} /t REG_DWORD /d {} /f", key, name, val))
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

fn selective_suspend() -> Option<(u32, u32)> {
    let o = Command::new("powercfg")
        .raw_arg(format!("/query SCHEME_CURRENT {} {}", USB_SUB, USB_SELECTIVE))
        .output()
        .ok()?;
    let t = String::from_utf8_lossy(&o.stdout).to_string();
    let v: Vec<u32> = t
        .lines()
        .filter_map(|l| {
            let p = l.find("0x")?;
            u32::from_str_radix(l[p + 2..].trim(), 16).ok()
        })
        .collect();
    if v.len() >= 2 {
        Some((v[v.len() - 2], v[v.len() - 1]))
    } else {
        None
    }
}

fn set_selective_suspend(on: bool) -> bool {
    let v = if on { 1 } else { 0 };
    let run = |args: String| {
        Command::new("powercfg")
            .raw_arg(args)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
            .map(|s| s.success())
            .unwrap_or(false)
    };
    let a = run(format!("/setacvalueindex SCHEME_CURRENT {} {} {}", USB_SUB, USB_SELECTIVE, v));
    let d = run(format!("/setdcvalueindex SCHEME_CURRENT {} {} {}", USB_SUB, USB_SELECTIVE, v));
    let s = run("/setactive SCHEME_CURRENT".to_string());
    a && d && s
}

struct UsbPolicy {
    storage: Option<u32>,
    wprotect: Option<u32>,
    suspend: Option<(u32, u32)>,
}

fn usb_policy() -> UsbPolicy {
    UsbPolicy {
        storage: reg_dword(KEY_USBSTOR, "Start"),
        wprotect: reg_dword(KEY_WPROTECT, "WriteProtect"),
        suspend: selective_suspend(),
    }
}

fn reset_device(id: &str) -> bool {
    let ok = Command::new("pnputil")
        .raw_arg(format!("/restart-device \"{}\"", id))
        .output()
        .map(|o| {
            println!("  {}{}{}", C_FROST, String::from_utf8_lossy(&o.stdout).trim(), C_RESET);
            o.status.success()
        })
        .unwrap_or(false);
    if !ok {
        println!(
            "  {}Yedek yöntem (devre dışı bırak / etkinleştir) uygulanıyor...{}",
            C_WARN, C_RESET
        );
        let q = ps_quote(id);
        let out = ps_report(
            &format!(
                "Disable-PnpDevice -InstanceId '{0}' -Confirm:$false -ErrorAction Stop; Start-Sleep -Seconds 2; \
                 Enable-PnpDevice -InstanceId '{0}' -Confirm:$false -ErrorAction Stop",
                q
            ),
            "Aygıt başarıyla sıfırlandı.",
        );
        return !out.starts_with("HATA");
    }
    true
}

fn usb_details(id: &str) -> String {
    let script = r#"
$id = '%ID%'
$d = Get-PnpDevice -InstanceId $id -ErrorAction SilentlyContinue
if (-not $d) { 'Aygıt bulunamadı.'; return }
'Ad              : ' + $d.FriendlyName
'Sınıf           : ' + $d.Class
'Durum           : ' + $d.Status
'Üretici         : ' + $d.Manufacturer
foreach ($k in 'DEVPKEY_Device_DriverVersion','DEVPKEY_Device_DriverDate','DEVPKEY_Device_LocationInfo','DEVPKEY_Device_Parent','DEVPKEY_Device_HardwareIds') {
  $p = Get-PnpDeviceProperty -InstanceId $id -KeyName $k -ErrorAction SilentlyContinue
  if ($p -and $p.Data) { ($k -replace 'DEVPKEY_Device_','').PadRight(16) + ': ' + (@($p.Data) -join ', ') }
}
"#;
    ps(&script.replace("%ID%", &ps_quote(id)))
}

fn usb_device_menu(d: &UsbDisplayItem) -> Nav {
    let is_storage = d.group == "BELLEK" && !d.letters.is_empty();
    loop {
        draw_header(&format!("USB AYGIT İŞLEMLERİ  ›  {}", d.title));
        draw_divider("SEÇİLİ AYGIT");
        println!("    {}{}{}", C_WHITE, d.title, C_RESET);
        println!("    {}{}   Durum: {}{}", C_ICE, d.meta, d.status, C_RESET);
        println!("    {}Donanım kimliği: {}{}", C_DIM, d.instance_id, C_RESET);
        if d.group == "HUB" {
            println!(
                "    {}{} Hub/denetleyici işlemleri üzerindeki tüm portları kısa süre koparır.{}",
                C_WARN, S_WARN, C_RESET
            );
        }
        println!();
        draw_divider("İŞLEMLER");
        opt_line("1", "Sıfırla (yeniden başlat)");
        opt_line("2", "Devre dışı bırak");
        opt_line("3", "Etkinleştir");
        opt_line("4", "Ayrıntılı bilgi (sürücü, üretici, konum, donanım kimlikleri)");
        if is_storage {
            opt_line("5", "Güvenli çıkar (sürücüyü sistemden ayır)");
            opt_line("6", "Sürücüyü Dosya Gezgini'nde aç");
        }
        opt_line("7", "Sistemden kaldır + yeniden tara (sert sıfırlama)");
        footer(true);

        let ch = match menu_key("Seçiminiz ›") {
            Mk::Home => return Nav::Home,
            Mk::Back => return Nav::Back,
            Mk::None => continue,
            Mk::Ch(c) => c,
        };
        let q = ps_quote(&d.instance_id);
        match ch {
            '0' => return Nav::Back,
            '1' => {
                if d.group == "HUB" && !confirm("Hub/denetleyici sıfırlansın mı? (e/h) ›") {
                    continue;
                }
                reset_device(&d.instance_id);
                pause();
            }
            '2' => {
                if confirm("Aygıt devre dışı bırakılsın mı? (e/h) ›") {
                    ps_report(
                        &format!("Disable-PnpDevice -InstanceId '{}' -Confirm:$false -ErrorAction Stop", q),
                        "Aygıt devre dışı bırakıldı.",
                    );
                    pause();
                }
            }
            '3' => {
                ps_report(
                    &format!("Enable-PnpDevice -InstanceId '{}' -Confirm:$false -ErrorAction Stop", q),
                    "Aygıt etkinleştirildi.",
                );
                pause();
            }
            '4' => {
                println!("  {}Bilgiler okunuyor...{}", C_FROST, C_RESET);
                for l in usb_details(&d.instance_id).lines().filter(|l| !l.trim().is_empty()) {
                    println!("  {}{}{}", C_WHITE, l, C_RESET);
                }
                pause();
            }
            '5' if is_storage => {
                for l in d.letters.split(',').filter(|l| !l.is_empty()) {
                    let l = ps_quote(l);
                    let script = format!(
                        "$s = New-Object -ComObject Shell.Application; \
                         $s.Namespace(17).ParseName('{0}').InvokeVerb('Eject'); \
                         Start-Sleep -Seconds 2; \
                         if (Test-Path '{0}\\') {{ throw 'Sürücü hâlâ kullanımda (açık dosya olabilir).' }}",
                        l
                    );
                    ps_report(&script, &format!("{} güvenle çıkarıldı. Aygıtı fiziksel olarak çıkarabilirsiniz.", l));
                }
                pause();
            }
            '6' if is_storage => {
                for l in d.letters.split(',').filter(|l| !l.is_empty()) {
                    let _ = Command::new("explorer").arg(format!("{}\\", l)).spawn();
                }
            }
            '7' => {
                if confirm("Aygıt sistemden kaldırılıp yeniden taransın mı? (e/h) ›") {
                    netsh_free("pnputil", format!("/remove-device \"{}\"", d.instance_id));
                    netsh_free("pnputil", "/scan-devices".to_string());
                    pause();
                }
            }
            _ => {}
        }
    }
}

// Herhangi bir komutu çalıştırıp çıktısını yazdırır
fn netsh_free(prog: &str, args: String) {
    match Command::new(prog).raw_arg(args).output() {
        Ok(o) => {
            let out = String::from_utf8_lossy(&o.stdout).trim().to_string();
            if !out.is_empty() {
                let col = if o.status.success() { C_OK } else { C_ERR };
                println!("  {}{}{}", col, out, C_RESET);
            }
            let e = String::from_utf8_lossy(&o.stderr).trim().to_string();
            if !e.is_empty() {
                println!("  {}{}{}", C_ERR, e, C_RESET);
            }
        }
        Err(e) => println!("  {}{} {} çalıştırılamadı: {}{}", C_ERR, S_ERR, prog, e, C_RESET),
    }
}

// Takma / çıkarma olaylarını canlı izler
fn usb_monitor() {
    draw_header("USB CANLI İZLEME  ›  takma / çıkarma olayları");
    println!(
        "  {}Bir USB aygıtı takıp çıkarın. Çıkmak için herhangi bir tuşa basın.{}\n",
        C_WARN, C_RESET
    );
    let stop = Arc::new(AtomicBool::new(false));
    let s2 = Arc::clone(&stop);
    thread::spawn(move || {
        let _ = raw_key();
        s2.store(true, Ordering::SeqCst);
    });
    let snap = |items: Vec<UsbDisplayItem>| -> Vec<(String, String)> {
        items.into_iter().map(|d| (d.instance_id, d.title)).collect()
    };
    let mut prev = snap(fetch_usb_items(true));
    println!("  {}[{}] Başlangıç: {} aygıt görünüyor.{}", C_DIM, clock(), prev.len(), C_RESET);
    while !stop.load(Ordering::SeqCst) {
        thread::sleep(Duration::from_millis(800));
        if stop.load(Ordering::SeqCst) {
            break;
        }
        let cur = snap(fetch_usb_items(true));
        for (id, title) in &cur {
            if !prev.iter().any(|(p, _)| p == id) {
                println!("  {}[{}] + TAKILDI   {}{}", C_OK, clock(), title, C_RESET);
            }
        }
        for (id, title) in &prev {
            if !cur.iter().any(|(c, _)| c == id) {
                println!("  {}[{}] - ÇIKARILDI {}{}", C_ERR, clock(), title, C_RESET);
            }
        }
        prev = cur;
    }
}

const USB_HOT: &[char] = &['h', 'r', 'm', 'u', 'y', 'v', 'w'];

fn usb_menu() -> Nav {
    let mut show_hubs = false;
    let mut devs: Vec<UsbDisplayItem> = Vec::new();
    let mut pol = UsbPolicy { storage: None, wprotect: None, suspend: None };
    let mut refresh = true;
    loop {
        if refresh {
            draw_header("USB PANEL KONTROLÜ");
            println!("  {}USB veri yolları taranıyor...{}", C_FROST, C_RESET);
            devs = fetch_usb_items(show_hubs);
            pol = usb_policy();
            refresh = false;
        }
        draw_header("USB PANEL KONTROLÜ");

        if devs.is_empty() {
            println!(
                "  {}{} Gösterilecek USB bellek veya uç aygıt bulunamadı.{}\n",
                C_WARN, S_WARN, C_RESET
            );
        } else {
            if devs.iter().any(|d| d.group == "BELLEK") {
                draw_divider("USB BELLEKLER & HARİCİ DİSKLER");
                for (i, d) in devs.iter().enumerate().filter(|(_, d)| d.group == "BELLEK") {
                    let st_col = if d.status == "OK" || d.status == "Healthy" { C_OK } else { C_WARN };
                    println!(
                        "    {}[{:>2}]{}  {}●{} {}{:<38}{}  {}[{}]{}",
                        C_NUM,
                        i + 1,
                        C_RESET,
                        st_col,
                        C_RESET,
                        C_WHITE,
                        d.title,
                        C_RESET,
                        C_ICE,
                        d.meta,
                        C_RESET
                    );
                }
                println!();
            }
            if devs.iter().any(|d| d.group == "AYGIT") {
                draw_divider("BAĞLI USB AYGITLARI");
                for (i, d) in devs.iter().enumerate().filter(|(_, d)| d.group == "AYGIT") {
                    let st_col = if d.status == "OK" { C_OK } else { C_WARN };
                    println!(
                        "    {}[{:>2}]{}  {}●{} {}{:<38}{}  {}{}{}",
                        C_NUM,
                        i + 1,
                        C_RESET,
                        st_col,
                        C_RESET,
                        C_WHITE,
                        d.title,
                        C_RESET,
                        C_DIM,
                        d.meta,
                        C_RESET
                    );
                }
                println!();
            }
            if show_hubs && devs.iter().any(|d| d.group == "HUB") {
                draw_divider("SİSTEM USB HUB & DENETLEYİCİLERİ");
                for (i, d) in devs.iter().enumerate().filter(|(_, d)| d.group == "HUB") {
                    println!(
                        "    {}[{:>2}]{}  {}{:<40}{}  {}{}{}",
                        C_NUM,
                        i + 1,
                        C_RESET,
                        C_FROST,
                        d.title,
                        C_RESET,
                        C_DIM,
                        d.meta,
                        C_RESET
                    );
                }
                println!();
            }
        }

        // Sistem düzeyi USB durumu
        draw_divider("USB SİSTEM DURUMU");
        let on = |b: bool, t: &str, f: &str| -> String {
            if b {
                format!("{}{}{}", C_OK, t, C_RESET)
            } else {
                format!("{}{}{}", C_WARN, f, C_RESET)
            }
        };
        println!(
            "    {}USB depolama erişimi :{} {}",
            C_DIM,
            C_RESET,
            match pol.storage {
                Some(4) => format!("{}ENGELLİ{}", C_ERR, C_RESET),
                Some(_) => on(true, "SERBEST", ""),
                None => format!("{}bilinmiyor{}", C_DIM, C_RESET),
            }
        );
        println!(
            "    {}Yazma koruması       :{} {}",
            C_DIM,
            C_RESET,
            match pol.wprotect {
                Some(1) => format!("{}AKTİF (salt okunur){}", C_WARN, C_RESET),
                _ => on(true, "KAPALI", ""),
            }
        );
        println!(
            "    {}Güç tasarrufu (askıya alma):{} {}",
            C_DIM,
            C_RESET,
            match pol.suspend {
                Some((ac, dc)) => format!(
                    "{}  {}(prize takılı: {} / pil: {}){}",
                    if ac == 0 && dc == 0 {
                        format!("{}KAPALI (aygıtlar uyumaz){}", C_OK, C_RESET)
                    } else {
                        format!("{}AÇIK (aygıtlar uyutulabilir){}", C_WARN, C_RESET)
                    },
                    C_DIM,
                    if ac == 0 { "kapalı" } else { "açık" },
                    if dc == 0 { "kapalı" } else { "açık" },
                    C_RESET
                ),
                None => format!("{}bilinmiyor{}", C_DIM, C_RESET),
            }
        );
        println!();

        draw_divider("KONTROLLER");
        opt_line("No", "Aygıt numarasını yazıp Enter: sıfırla / devre dışı / çıkar / ayrıntı ...");
        opt_line(
            "h",
            if show_hubs {
                "Sistem hub ve denetleyicilerini gizle"
            } else {
                "Sistem hub ve denetleyicilerini göster"
            },
        );
        opt_line("r", "Listeyi yenile");
        opt_line("m", "Canlı izleme (takılma / çıkarma olaylarını anında göster)");
        opt_line("u", "USB güç tasarrufunu (selective suspend) aç / kapat");
        opt_line("y", "USB depolama erişimini engelle / serbest bırak");
        opt_line("v", "Yazma korumasını (salt okunur) aç / kapat");
        opt_line("w", "Tüm USB denetleyicilerini sıfırla (hepsini yeniden başlat)");
        footer(true);

        match read_input("Aygıt No veya komut ›", Some(USB_HOT)) {
            Input::Home => return Nav::Home,
            Input::Back => return Nav::Back,
            Input::Hot(c) => {
                if global_key(c) {
                    continue;
                }
                match c {
                    'h' => {
                        show_hubs = !show_hubs;
                        refresh = true;
                    }
                    'r' => refresh = true,
                    'm' => usb_monitor(),
                    'u' => {
                        let currently_on = pol.suspend.map(|(a, d)| a != 0 || d != 0).unwrap_or(true);
                        if set_selective_suspend(!currently_on) {
                            flash_ok(if currently_on {
                                "USB güç tasarrufu KAPATILDI (aygıtlar uyutulmaz).".to_string()
                            } else {
                                "USB güç tasarrufu AÇILDI.".to_string()
                            });
                        } else {
                            flash_err("Güç ayarı değiştirilemedi (yönetici izni gerekli olabilir).".to_string());
                        }
                        pol = usb_policy();
                    }
                    'y' => {
                        let blocked = pol.storage == Some(4);
                        if reg_set_dword(KEY_USBSTOR, "Start", if blocked { 3 } else { 4 }) {
                            flash_ok(if blocked {
                                "USB depolama erişimi SERBEST bırakıldı (yeni takılan bellekler çalışır).".to_string()
                            } else {
                                "USB depolama ENGELLENDİ (yeni takılan bellekler tanınmaz).".to_string()
                            });
                        } else {
                            flash_err("Kayıt defteri yazılamadı (yönetici izni gerekli).".to_string());
                        }
                        pol = usb_policy();
                    }
                    'v' => {
                        let active = pol.wprotect == Some(1);
                        if reg_set_dword(KEY_WPROTECT, "WriteProtect", if active { 0 } else { 1 }) {
                            flash_ok(if active {
                                "Yazma koruması KAPATILDI (bellekleri yeniden takın).".to_string()
                            } else {
                                "Yazma koruması AÇILDI: belleklere yazılamaz (bellekleri yeniden takın).".to_string()
                            });
                        } else {
                            flash_err("Kayıt defteri yazılamadı (yönetici izni gerekli).".to_string());
                        }
                        pol = usb_policy();
                    }
                    'w' => {
                        println!(
                            "\n  {}{} Tüm USB denetleyicileri yeniden başlatılır: klavye/fare dahil bütün USB aygıtlar birkaç saniye kopar.{}",
                            C_WARN, S_WARN, C_RESET
                        );
                        if confirm("Devam edilsin mi? (e/h) ›") {
                            let all = fetch_usb_items(true);
                            let mut n = 0;
                            for d in all.iter().filter(|d| d.group == "HUB") {
                                let t = d.title.to_lowercase();
                                if t.contains("host controller")
                                    || t.contains("denetleyici")
                                    || t.contains("root hub")
                                    || t.contains("kök")
                                {
                                    println!("  {}{} {}{}", C_ICE, S_ARROW, d.title, C_RESET);
                                    if reset_device(&d.instance_id) {
                                        n += 1;
                                    }
                                }
                            }
                            flash_ok(format!("{} USB denetleyici / kök hub yeniden başlatıldı.", n));
                            refresh = true;
                        }
                    }
                    _ => {}
                }
            }
            Input::Text(t) => {
                let n: usize = match t.parse() {
                    Ok(n) => n,
                    Err(_) => continue,
                };
                if n == 0 {
                    return Nav::Back;
                }
                if n > devs.len() {
                    continue;
                }
                let nav = usb_device_menu(&devs[n - 1]);
                refresh = true;
                if nav == Nav::Home {
                    return Nav::Home;
                }
            }
        }
    }
}

// ───────────────────────── Ana menü ─────────────────────────

fn main_menu() {
    let admin = is_admin();
    loop {
        draw_header("SUNUCU KURMA  •  ETHERNET AYARI  •  USB PANEL KONTROLÜ");
        if !admin {
            println!(
                "  {}{} Yönetici izni verilmedi: IP atama, hız ayarı ve USB işlemleri hata verebilir.{}\n",
                C_WARN, S_WARN, C_RESET
            );
        }
        draw_divider("ANA MENÜ");
        opt_line("1", "Sunucu Kurma         (cihaz sunucuları: başlat / izle / IP / port / test / terminal)");
        opt_line("2", "Ethernet IP Ayarı    (statik / çoklu IP / DHCP / DNS / MTU / ping)");
        opt_line("3", "Ethernet Hız Ayarı    (adaptörün desteklediği tüm hız & duplex seçenekleri)");
        opt_line("4", "USB Panel Kontrolü    (sıfırla / çıkar / izle / güç & yazma koruması)");
        footer(false);

        match menu_key("Seçiminiz ›") {
            Mk::Ch('1') => {
                devices_menu();
            }
            Mk::Ch('2') => {
                ip_menu();
            }
            Mk::Ch('3') => {
                speed_menu();
            }
            Mk::Ch('4') => {
                usb_menu();
            }
            Mk::Ch('0') => return,
            _ => {}
        }
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 3 && args[1] == "--serve" {
        if let Some(k) = Kind::from_id(&args[2]) {
            let ip = args.get(3).cloned().unwrap_or_else(|| get_configured_ip(k));
            let port = args
                .get(4)
                .and_then(|p| p.parse().ok())
                .unwrap_or_else(|| get_configured_port(k));
            run_server(k, &ip, port);
        }
        return;
    }
    if !is_admin() && relaunch_as_admin() {
        return;
    }
    let _ = prepare_daemon_exe();
    setup_iceglass_console();
    main_menu();
}