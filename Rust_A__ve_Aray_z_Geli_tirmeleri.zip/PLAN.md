# MULTITOOL (Keysight Tech) — Geliştirme Planı

Mevcut kod: `main.rs`, 2843 satır, yalnızca Windows, bağımlılıksız (std + FFI). Mimari: menü exe + `--serve` ile ayrılan arka plan sunucu süreci (C:\ProgramData\KeysightSim).
Hiçbir şey henüz uygulanmadı. Aşağıyı düzeltin, sonra "uygula" deyin.

## 0. Tespit edilen kök sorunlar
| Bulgu | Etki |
|---|---|
| `ensure_ip_on_system` IP'yi **Loopback Pseudo-Interface 1**'e /32 ekliyor | Sunucu yalnızca bu bilgisayardan erişilebilir; cihaz/LAN'dan "bağlanamıyor" olmasının en olası nedeni |
| Gelen bağlantı için **güvenlik duvarı kuralı yok** | Dışarıdan bağlantı sessizce düşer |
| "Çalışıyor" kontrolü yalnızca PID dosyası + tasklist | Süreç var ama soket yanıt vermiyor olabilir |
| Konsol sabit `FONT_SIZE=18`, `cols=100 lines=46` | Çözünürlüğe uyum yok |
| Kısayol eşlemesi `hot()` var ama komut/metin karşılaştırmalarında tutarsız olabilir | ı/I/i/İ farkı |

## 1. Altyapı (önce yapılacak)
1. **Yönetici zorunluluğunu kaldır**: otomatik `relaunch_as_admin` silinir. Yönetici gerektiren her satırda `[YÖNETİCİ]` rozeti; yönetici olarak çalışıyorsa rozet görünmez. Yetkisiz işlemde net hata mesajı (çökme yok).
2. **Üst log şeridi**: ekranın en üstünde sabit 4 satır; yeni olay altta eklenir, eskiler yukarı kayar. Tüm `flash_*` çağrıları buraya akar (zaman damgalı, renkli).
3. **Sunucu kontrolü paneli** yalnızca Ana Menü + 1. seçenekte; diğer menülerden kaldırılır (global n/s/g/a/k kısayolları da yalnızca bu iki ekranda).
4. **Ayrıntılı ağ bilgisi** (adaptör, IP, MAC, hız, durum) tüm Ethernet menülerinde otomatik görünür; IP menüsünden "ayrıntılı ağ bilgisi" seçeneği kaldırılır.
5. Ana başlık: "SUNUCU KURMA" → **KEYSIGHT TECH**.

## 2. Çözünürlüğe duyarlı yazı tipi (geleceğe dönük)
- Başlangıçta `GetSystemMetrics` / `MonitorFromWindow + GetMonitorInfo` ile ekran piksel boyutu ve `GetDpiForSystem` okunur.
- Hedef: pencere ekranın ~%70 genişliği/%85 yüksekliğine sığsın → `font_px = min(ekran_w*0.70/(COLS*0.55), ekran_h*0.85/LINES)`, 14–48 px arası sınırlanır. Sabit çözünürlük listesi yok, formül her çözünürlükte çalışır.
- Çalışma sırasında çözünürlük/DPI değişirse (her menü çiziminde ucuz kontrol) yazı tipi yeniden hesaplanır. Pencere ekran ortasına konumlanır.
- "Harfleri büyüt" isteği: taban katsayı büyütülür (daha büyük varsayılan).

## 3. Türkçe ı/I/i/İ eşitleme
- Tüm menü tuşları, komut girişleri ve metin karşılaştırmaları tek `norm()` fonksiyonundan geçer (`ı İ I i → i`, büyük/küçük harf duyarsız).
- SCPI komut eşleştirmesi (`scpi_eq`) da aynı normalizasyonu kullanır.

## 4. Sunucuların %100 çalıştığının garantisi
1. **Gerçek sağlık denetimi**: başlatma sonrası ve izleme sırasında sunucuya TCP bağlanıp `*IDN?` gönderilir, yanıt doğrulanır → rozet: `ÇALIŞIYOR ✔ (yanıt 3 ms)` / `SÜREÇ VAR ama YANIT YOK`.
2. **Gözetmen (watchdog)**: menü açıkken 3 sn'de bir kontrol; ölen/yanıtsız sunucu otomatik yeniden başlatılır, log şeridine yazılır.
3. **Bağlantı sorunu düzeltmesi**: IP, loopback yerine **seçilen gerçek Ethernet adaptörüne** ikincil IP olarak eklenir (yoksa loopback + uyarı); `0.0.0.0` yerine doğru bind; bağlantı yoksa neden raporlanır (IP sistemde yok / port dolu / duvar).
4. **Otomatik güvenlik duvarı kuralı** (yönetici varsa) sunucu portları için; yoksa `[YÖNETİCİ]` uyarısı.
5. Port çakışması için başlamadan önce kontrol, açık hata mesajı.

## 5. Bağlantı adresleri: IP + VISA
- Her sunucuda iki adres: `192.168.x.x:5025` ve `TCPIP0::192.168.x.x::5025::SOCKET`.
- Panoya sırayla yazılır: önce **VISA**, sonra **IP** (son kopya = Ctrl+V'de IP; Win+V geçmişinde ikisi de görünür). Pano geçmişi Windows'ta açık olmalı (Ayarlar > Pano) — ilk kullanımda uyarı verilir.

## 6. Cihaz modeli seçimi (kimlik değiştirme kalkar)
- `*IDN?` serbest düzenleme kaldırılır; yerine **21 model × 7 adet = 147** kayıt: 3 sunucu türü (Network Analyzer, Spectrum Analyzer, Jeneratör) × 7 model-serisi… 
  Varsayılan düzen: 21 model adı (gerçek Keysight model numaraları: ör. E5071C, N9020A, N5181A…) ve her biri için 7 seri numaralı örnek. Listeden seçilir, `*IDN?` yanıtı otomatik üretilir.
- (Yorumum: "21 model, her birinden 7 tane" = 21 model, her modelin 7 seri/örneği. Aksi ise belirtin.)

## 7. Ping & Cihaz İzleme (yeni menüler)
1. **Ping Testi menüsü**: hedef gir → anlık satır satır yanıt (süre/TTL, canlı), tek seferlik veya **sürekli ping** (Esc ile durur), istatistik özeti (kayıp %, min/ort/maks).
2. **Statik Cihaz Listesi** (kodda JSON-benzeri sabit dizi): `{ "ad", "ip", "mac" }` — siz dolduracaksınız. Yalnızca ping ile çalışır/çalışmaz durumu gösterir.
3. **Kayıtlı cihazlar menüsü**: çoklu IP ekle/sil (cihaz adı, IP, geçerli MAC) ve "Tümünü kontrol et": ping + ARP sorgusundan dönen IP/MAC, girilen değerlerle karşılaştırılır → `UYUMLU / MAC FARKLI / ERİŞİLEMİYOR`. Kalıcı dosya: `devices.json` (ProgramData) + koddaki gömülü dizi birleştirilir.

## 8. Yeni araçlar
- **USB güvenli çıkarma**: çıkarılabilir diskleri listele, seçileni önbelleği boşaltıp güvenle çıkar (PowerShell/Shell eject).
- **Fare tıklayıcısı**: varsayılan 5 sn aralıkla sol tık (`SendInput`), süre ayarı, ekstra: tık sayısı limiti, başlama gecikmesi, açık/kapa kısayolu, tık sayacı; Esc ile durur.
- **Güvenlik duvarı**: tek tuşla tüm profilleri aç/kapat (`[YÖNETİCİ]`); **uygulama listesi** (çalışan süreçler/exe) → seçileni gelen+giden izin kuralıyla beyaz listeye ekle.
- **Uyku engelleyici**: sessiz, arka planda `SetThreadExecutionState(ES_CONTINUOUS|SYSTEM_REQUIRED|AWAYMODE)` — ekran/menü göstergesi yok, kullanıcıya bildirim yok, program açıldığında otomatik aktif; ayrı bir canlı iş parçacığı ile periyodik yenilenir.

## 9. Ekstra önerilerim
- Ayarlar kalıcılığı (`settings.json`: son seçimler, tık aralığı, font katsayısı).
- Tüm işlemler için `multitool.log` dosyası.
- Port tarayıcı yerine yalnızca **yerel port-kullanım kontrolü** (kimin 5025'i tuttuğu).
- Ağ adaptörü yedek/geri al (IP ayarını değiştirmeden önce eski ayarı kaydet).

## 10. Uygulama sırası
1) Altyapı (log şeridi, yönetici rozeti, norm(), font) → 2) sunucu sağlığı/bağlantı düzeltmesi + VISA/IP pano + model listesi → 3) Ping/cihaz izleme → 4) USB eject, fare, duvar, uyku → 5) derleme denemesi (`cargo check --target x86_64-pc-windows-gnu`) ve menü gözden geçirme.

## Netleştirmek istediğim varsayımlar (değiştirmek isterseniz yazın)
- Bağlanamama kök nedeni büyük olasılıkla loopback IP + güvenlik duvarı; düzeltme buna göre.
- Ekranda 21 model: gerçek Keysight model numaraları kullanılacak.
- Statik cihaz dizisi `main.rs` içinde, kullanıcı kayıtları ayrıca `devices.json`'da.
- Windows 10/11, harici crate yok (derleme kolaylığı).
